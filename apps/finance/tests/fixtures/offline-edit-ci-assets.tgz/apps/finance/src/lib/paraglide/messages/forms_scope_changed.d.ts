export { forms_scope_changed as "forms.scope_changed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Scope_ChangedInputs = {};
/**
* | output |
* | --- |
* | "The workspace, identity, record or your access changed before this request completed." |
*
* @param {Forms_Scope_ChangedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_scope_changed: ((inputs?: Forms_Scope_ChangedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Scope_ChangedInputs, {
    locale?: "en";
}, {}>;
