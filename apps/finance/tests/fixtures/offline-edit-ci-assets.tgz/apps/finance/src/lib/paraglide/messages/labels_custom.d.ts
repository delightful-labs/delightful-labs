export { labels_custom as "labels.custom" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_CustomInputs = {};
/**
* | output |
* | --- |
* | "Custom" |
*
* @param {Labels_CustomInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_custom: ((inputs?: Labels_CustomInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_CustomInputs, {
    locale?: "en";
}, {}>;
