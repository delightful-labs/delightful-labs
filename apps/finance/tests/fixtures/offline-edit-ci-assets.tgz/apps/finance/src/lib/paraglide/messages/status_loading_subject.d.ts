export { status_loading_subject as "status.loading_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Loading_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Loading {subject}…" |
*
* @param {Status_Loading_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_loading_subject: ((inputs: Status_Loading_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Loading_SubjectInputs, {
    locale?: "en";
}, {}>;
