export { bank_log_title as "bank.log_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Log_TitleInputs = {};
/**
* | output |
* | --- |
* | "Sync history" |
*
* @param {Bank_Log_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_log_title: ((inputs?: Bank_Log_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Log_TitleInputs, {
    locale?: "en";
}, {}>;
