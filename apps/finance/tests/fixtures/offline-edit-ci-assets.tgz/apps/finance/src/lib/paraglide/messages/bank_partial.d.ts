export { bank_partial as "bank.partial" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_PartialInputs = {};
/**
* | output |
* | --- |
* | "Partial" |
*
* @param {Bank_PartialInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_partial: ((inputs?: Bank_PartialInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_PartialInputs, {
    locale?: "en";
}, {}>;
