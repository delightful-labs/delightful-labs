export { forms_linked_transfer_requires_unlink as "forms.linked_transfer_requires_unlink" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Linked_Transfer_Requires_UnlinkInputs = {};
/**
* | output |
* | --- |
* | "Unlink this transfer before changing its amount, account, or currency." |
*
* @param {Forms_Linked_Transfer_Requires_UnlinkInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_linked_transfer_requires_unlink: ((inputs?: Forms_Linked_Transfer_Requires_UnlinkInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Linked_Transfer_Requires_UnlinkInputs, {
    locale?: "en";
}, {}>;
