export { labels_status_subject as "labels.status_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Status_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} status" |
*
* @param {Labels_Status_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_status_subject: ((inputs: Labels_Status_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Status_SubjectInputs, {
    locale?: "en";
}, {}>;
