export { labels_description as "labels.description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "Description" |
*
* @param {Labels_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_description: ((inputs?: Labels_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_DescriptionInputs, {
    locale?: "en";
}, {}>;
