export { errors_archive_subject as "errors.archive_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Archive_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Could not archive {subject}." |
*
* @param {Errors_Archive_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_archive_subject: ((inputs: Errors_Archive_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Archive_SubjectInputs, {
    locale?: "en";
}, {}>;
