export { accounts_archive_session_unavailable as "accounts.archive_session_unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Archive_Session_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "Account actions are unavailable until your session is ready." |
*
* @param {Accounts_Archive_Session_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_archive_session_unavailable: ((inputs?: Accounts_Archive_Session_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Archive_Session_UnavailableInputs, {
    locale?: "en";
}, {}>;
