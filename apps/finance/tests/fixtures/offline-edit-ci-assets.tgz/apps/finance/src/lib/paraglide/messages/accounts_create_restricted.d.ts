export { accounts_create_restricted as "accounts.create_restricted" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Create_RestrictedInputs = {};
/**
* | output |
* | --- |
* | "Only workspace owners and admins can add accounts." |
*
* @param {Accounts_Create_RestrictedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_create_restricted: ((inputs?: Accounts_Create_RestrictedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Create_RestrictedInputs, {
    locale?: "en";
}, {}>;
