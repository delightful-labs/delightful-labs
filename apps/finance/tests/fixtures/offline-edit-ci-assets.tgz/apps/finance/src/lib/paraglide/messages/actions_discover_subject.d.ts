export { actions_discover_subject as "actions.discover_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Discover_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Discover {subject}" |
*
* @param {Actions_Discover_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_discover_subject: ((inputs: Actions_Discover_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Discover_SubjectInputs, {
    locale?: "en";
}, {}>;
