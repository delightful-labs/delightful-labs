export { image_editor_reset as "image_editor.reset" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_ResetInputs = {};
/**
* | output |
* | --- |
* | "Reset Image" |
*
* @param {Image_Editor_ResetInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_reset: ((inputs?: Image_Editor_ResetInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_ResetInputs, {
    locale?: "en";
}, {}>;
