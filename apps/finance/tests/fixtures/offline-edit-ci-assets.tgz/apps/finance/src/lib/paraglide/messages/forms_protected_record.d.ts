export { forms_protected_record as "forms.protected_record" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Protected_RecordInputs = {};
/**
* | output |
* | --- |
* | "System categories cannot be archived." |
*
* @param {Forms_Protected_RecordInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_protected_record: ((inputs?: Forms_Protected_RecordInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Protected_RecordInputs, {
    locale?: "en";
}, {}>;
