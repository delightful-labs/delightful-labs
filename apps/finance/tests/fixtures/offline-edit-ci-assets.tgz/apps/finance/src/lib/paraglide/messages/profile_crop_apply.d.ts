export { profile_crop_apply as "profile.crop_apply" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_ApplyInputs = {};
/**
* | output |
* | --- |
* | "Use this crop" |
*
* @param {Profile_Crop_ApplyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_apply: ((inputs?: Profile_Crop_ApplyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_ApplyInputs, {
    locale?: "en";
}, {}>;
