export { labels_subject_type as "labels.subject_type" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_TypeInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} type" |
*
* @param {Labels_Subject_TypeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_type: ((inputs: Labels_Subject_TypeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_TypeInputs, {
    locale?: "en";
}, {}>;
