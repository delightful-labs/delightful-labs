export { image_editor_edit as "image_editor.edit" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_EditInputs = {};
/**
* | output |
* | --- |
* | "Edit Image" |
*
* @param {Image_Editor_EditInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_edit: ((inputs?: Image_Editor_EditInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_EditInputs, {
    locale?: "en";
}, {}>;
