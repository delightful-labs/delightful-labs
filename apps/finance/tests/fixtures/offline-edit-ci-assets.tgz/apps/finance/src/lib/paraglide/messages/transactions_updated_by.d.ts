export { transactions_updated_by as "transactions.updated_by" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Updated_ByInputs = {};
/**
* | output |
* | --- |
* | "Last edited by" |
*
* @param {Transactions_Updated_ByInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_updated_by: ((inputs?: Transactions_Updated_ByInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Updated_ByInputs, {
    locale?: "en";
}, {}>;
