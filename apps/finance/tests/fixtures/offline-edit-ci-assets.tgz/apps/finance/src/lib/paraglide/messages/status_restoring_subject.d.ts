export { status_restoring_subject as "status.restoring_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Restoring_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Restoring {subject}…" |
*
* @param {Status_Restoring_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_restoring_subject: ((inputs: Status_Restoring_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Restoring_SubjectInputs, {
    locale?: "en";
}, {}>;
