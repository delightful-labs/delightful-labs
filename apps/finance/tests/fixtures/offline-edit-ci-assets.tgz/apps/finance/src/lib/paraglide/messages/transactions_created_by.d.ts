export { transactions_created_by as "transactions.created_by" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Created_ByInputs = {};
/**
* | output |
* | --- |
* | "Created by" |
*
* @param {Transactions_Created_ByInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_created_by: ((inputs?: Transactions_Created_ByInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Created_ByInputs, {
    locale?: "en";
}, {}>;
