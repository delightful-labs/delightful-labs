export { status_unavailable_subject as "status.unavailable_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Unavailable_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} unavailable" |
*
* @param {Status_Unavailable_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_unavailable_subject: ((inputs: Status_Unavailable_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Unavailable_SubjectInputs, {
    locale?: "en";
}, {}>;
