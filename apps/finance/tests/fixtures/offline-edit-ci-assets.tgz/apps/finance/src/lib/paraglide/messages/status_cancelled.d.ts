export { status_cancelled as "status.cancelled" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_CancelledInputs = {};
/**
* | output |
* | --- |
* | "The request was cancelled." |
*
* @param {Status_CancelledInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_cancelled: ((inputs?: Status_CancelledInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_CancelledInputs, {
    locale?: "en";
}, {}>;
