export { actions_edit_subject as "actions.edit_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Edit_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Edit {subject}" |
*
* @param {Actions_Edit_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_edit_subject: ((inputs: Actions_Edit_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Edit_SubjectInputs, {
    locale?: "en";
}, {}>;
