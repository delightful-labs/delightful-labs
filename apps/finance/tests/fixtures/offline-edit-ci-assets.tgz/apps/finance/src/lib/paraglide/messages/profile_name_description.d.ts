export { profile_name_description as "profile.name_description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Name_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "Leave the name blank to use your account ID." |
*
* @param {Profile_Name_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_name_description: ((inputs?: Profile_Name_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Name_DescriptionInputs, {
    locale?: "en";
}, {}>;
