export { bank_restricted as "bank.restricted" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_RestrictedInputs = {};
/**
* | output |
* | --- |
* | "Select a workspace where you are an owner or admin to manage your own bank connection." |
*
* @param {Bank_RestrictedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_restricted: ((inputs?: Bank_RestrictedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_RestrictedInputs, {
    locale?: "en";
}, {}>;
