export { sync_mutation_rejected as "sync.mutation_rejected" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Sync_Mutation_RejectedInputs = {};
/**
* | output |
* | --- |
* | "A change was rejected while syncing. Your data reflects the latest accepted changes." |
*
* @param {Sync_Mutation_RejectedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const sync_mutation_rejected: ((inputs?: Sync_Mutation_RejectedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Sync_Mutation_RejectedInputs, {
    locale?: "en";
}, {}>;
