export { overview_expenses_chart as "overview_expenses.chart" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Overview_Expenses_ChartInputs = {};
/**
* | output |
* | --- |
* | "Expense totals by category. Select a slice or a category below to filter transactions." |
*
* @param {Overview_Expenses_ChartInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const overview_expenses_chart: ((inputs?: Overview_Expenses_ChartInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Overview_Expenses_ChartInputs, {
    locale?: "en";
}, {}>;
