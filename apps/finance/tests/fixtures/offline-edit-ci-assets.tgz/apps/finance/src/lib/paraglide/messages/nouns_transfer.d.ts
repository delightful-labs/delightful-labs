export { nouns_transfer as "nouns.transfer" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_TransferInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Transfer" |
* | * | "Transfers" |
*
* @param {Nouns_TransferInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_transfer: ((inputs: Nouns_TransferInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_TransferInputs, {
    locale?: "en";
}, {}>;
