export { app_description as "app.description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type App_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "A local-first personal finance tracker." |
*
* @param {App_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const app_description: ((inputs?: App_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<App_DescriptionInputs, {
    locale?: "en";
}, {}>;
