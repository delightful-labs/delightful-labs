export { labels_last_week as "labels.last_week" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Last_WeekInputs = {};
/**
* | output |
* | --- |
* | "Last week" |
*
* @param {Labels_Last_WeekInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_last_week: ((inputs?: Labels_Last_WeekInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Last_WeekInputs, {
    locale?: "en";
}, {}>;
