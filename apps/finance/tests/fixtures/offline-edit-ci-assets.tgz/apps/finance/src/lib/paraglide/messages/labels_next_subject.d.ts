export { labels_next_subject as "labels.next_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Next_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Next {subject}" |
*
* @param {Labels_Next_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_next_subject: ((inputs: Labels_Next_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Next_SubjectInputs, {
    locale?: "en";
}, {}>;
