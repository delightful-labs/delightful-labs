export { transactions_check_retained as "transactions.check_retained" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Check_RetainedInputs = {};
/**
* | output |
* | --- |
* | "The Check was saved, but the transaction was not. Save again to reuse the same Check." |
*
* @param {Transactions_Check_RetainedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_check_retained: ((inputs?: Transactions_Check_RetainedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Check_RetainedInputs, {
    locale?: "en";
}, {}>;
