export { labels_no_subjects_in_period as "labels.no_subjects_in_period" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_No_Subjects_In_PeriodInputs = {
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "No {subjects} in this time period." |
*
* @param {Labels_No_Subjects_In_PeriodInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_no_subjects_in_period: ((inputs: Labels_No_Subjects_In_PeriodInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_No_Subjects_In_PeriodInputs, {
    locale?: "en";
}, {}>;
