export { login_description as "login.description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Login_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "Enter the recovery phrase for an existing local-first account." |
*
* @param {Login_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const login_description: ((inputs?: Login_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Login_DescriptionInputs, {
    locale?: "en";
}, {}>;
