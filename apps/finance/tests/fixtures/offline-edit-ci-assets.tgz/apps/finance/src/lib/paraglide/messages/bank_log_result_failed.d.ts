export { bank_log_result_failed as "bank.log_result_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Log_Result_FailedInputs = {};
/**
* | output |
* | --- |
* | "The sync ended, but its final log details could not be saved. The import result shown still applies." |
*
* @param {Bank_Log_Result_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_log_result_failed: ((inputs?: Bank_Log_Result_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Log_Result_FailedInputs, {
    locale?: "en";
}, {}>;
