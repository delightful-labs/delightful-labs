export { navigation_label as "navigation.label" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Navigation_LabelInputs = {};
/**
* | output |
* | --- |
* | "Main navigation" |
*
* @param {Navigation_LabelInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const navigation_label: ((inputs?: Navigation_LabelInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Navigation_LabelInputs, {
    locale?: "en";
}, {}>;
