export { bank_step_verify as "bank.step_verify" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Step_VerifyInputs = {};
/**
* | output |
* | --- |
* | "Test unlocking" |
*
* @param {Bank_Step_VerifyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_step_verify: ((inputs?: Bank_Step_VerifyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Step_VerifyInputs, {
    locale?: "en";
}, {}>;
