export { workspace_setup_error as "workspace.setup_error" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Setup_ErrorInputs = {};
/**
* | output |
* | --- |
* | "Your workspaces could not be prepared." |
*
* @param {Workspace_Setup_ErrorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_setup_error: ((inputs?: Workspace_Setup_ErrorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Setup_ErrorInputs, {
    locale?: "en";
}, {}>;
