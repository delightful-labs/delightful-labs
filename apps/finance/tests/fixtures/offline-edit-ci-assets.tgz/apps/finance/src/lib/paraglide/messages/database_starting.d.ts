export { database_starting as "database.starting" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Database_StartingInputs = {};
/**
* | output |
* | --- |
* | "Loading your finances…" |
*
* @param {Database_StartingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const database_starting: ((inputs?: Database_StartingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Database_StartingInputs, {
    locale?: "en";
}, {}>;
