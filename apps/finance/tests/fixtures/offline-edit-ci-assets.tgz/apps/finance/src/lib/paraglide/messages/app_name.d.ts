export { app_name as "app.name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type App_NameInputs = {};
/**
* | output |
* | --- |
* | "Delightful Finance" |
*
* @param {App_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const app_name: ((inputs?: App_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<App_NameInputs, {
    locale?: "en";
}, {}>;
