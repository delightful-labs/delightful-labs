export { bank_partial_success as "bank.partial_success" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Partial_SuccessInputs = {};
/**
* | output |
* | --- |
* | "Sync completed with some records omitted or provider errors. Credential locked." |
*
* @param {Bank_Partial_SuccessInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_partial_success: ((inputs?: Bank_Partial_SuccessInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Partial_SuccessInputs, {
    locale?: "en";
}, {}>;
