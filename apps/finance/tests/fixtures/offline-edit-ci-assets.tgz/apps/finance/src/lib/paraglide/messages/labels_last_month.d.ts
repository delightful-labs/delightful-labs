export { labels_last_month as "labels.last_month" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Last_MonthInputs = {};
/**
* | output |
* | --- |
* | "Last month" |
*
* @param {Labels_Last_MonthInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_last_month: ((inputs?: Labels_Last_MonthInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Last_MonthInputs, {
    locale?: "en";
}, {}>;
