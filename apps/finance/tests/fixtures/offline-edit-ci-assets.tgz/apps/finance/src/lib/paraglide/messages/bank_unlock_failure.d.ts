export { bank_unlock_failure as "bank.unlock_failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Unlock_FailureInputs = {};
/**
* | output |
* | --- |
* | "Your original passkey could not unlock this credential, verification was cancelled, or the encrypted record is invalid. No provider request was made. Try a c..." |
*
* @param {Bank_Unlock_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_unlock_failure: ((inputs?: Bank_Unlock_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Unlock_FailureInputs, {
    locale?: "en";
}, {}>;
