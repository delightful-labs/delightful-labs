export { workspace_unavailable as "workspace.unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "This workspace or transaction is unavailable. Select a workspace you can access." |
*
* @param {Workspace_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_unavailable: ((inputs?: Workspace_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_UnavailableInputs, {
    locale?: "en";
}, {}>;
