export { nouns_tag as "nouns.tag" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_TagInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Tag" |
* | * | "Tags" |
*
* @param {Nouns_TagInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_tag: ((inputs: Nouns_TagInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_TagInputs, {
    locale?: "en";
}, {}>;
