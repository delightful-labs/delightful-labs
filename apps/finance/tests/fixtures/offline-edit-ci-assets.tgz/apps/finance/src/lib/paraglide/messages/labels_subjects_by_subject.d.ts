export { labels_subjects_by_subject as "labels.subjects_by_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subjects_By_SubjectInputs = {
    subjects: NonNullable<unknown>;
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subjects} by {subject}" |
*
* @param {Labels_Subjects_By_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subjects_by_subject: ((inputs: Labels_Subjects_By_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subjects_By_SubjectInputs, {
    locale?: "en";
}, {}>;
