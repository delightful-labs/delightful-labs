export { bank_setup_creating_title as "bank.setup_creating_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Creating_TitleInputs = {};
/**
* | output |
* | --- |
* | "Step 2: Create your passkey" |
*
* @param {Bank_Setup_Creating_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_creating_title: ((inputs?: Bank_Setup_Creating_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Creating_TitleInputs, {
    locale?: "en";
}, {}>;
