export { bank_step_upcoming as "bank.step_upcoming" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Step_UpcomingInputs = {};
/**
* | output |
* | --- |
* | "not completed" |
*
* @param {Bank_Step_UpcomingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_step_upcoming: ((inputs?: Bank_Step_UpcomingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Step_UpcomingInputs, {
    locale?: "en";
}, {}>;
