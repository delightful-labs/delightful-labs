export { actions_add_subject_name as "actions.add_subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Add_Subject_NameInputs = {
    subject: NonNullable<unknown>;
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Add {subject} “{name}”" |
*
* @param {Actions_Add_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_add_subject_name: ((inputs: Actions_Add_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Add_Subject_NameInputs, {
    locale?: "en";
}, {}>;
