export { actions_add_another_subject as "actions.add_another_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Add_Another_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Add another {subject}" |
*
* @param {Actions_Add_Another_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_add_another_subject: ((inputs: Actions_Add_Another_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Add_Another_SubjectInputs, {
    locale?: "en";
}, {}>;
