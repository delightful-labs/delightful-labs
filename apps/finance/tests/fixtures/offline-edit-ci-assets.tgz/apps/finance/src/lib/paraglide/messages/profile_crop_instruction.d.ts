export { profile_crop_instruction as "profile.crop_instruction" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_InstructionInputs = {};
/**
* | output |
* | --- |
* | "Drag the crop area to choose which part of the image to keep." |
*
* @param {Profile_Crop_InstructionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_instruction: ((inputs?: Profile_Crop_InstructionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_InstructionInputs, {
    locale?: "en";
}, {}>;
