export { image_editor_perspective as "image_editor.perspective" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_PerspectiveInputs = {};
/**
* | output |
* | --- |
* | "Perspective correction" |
*
* @param {Image_Editor_PerspectiveInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_perspective: ((inputs?: Image_Editor_PerspectiveInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_PerspectiveInputs, {
    locale?: "en";
}, {}>;
