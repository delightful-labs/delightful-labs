export { image_editor_resize_top_right as "image_editor.resize_top_right" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Resize_Top_RightInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from top right corner" |
*
* @param {Image_Editor_Resize_Top_RightInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_resize_top_right: ((inputs?: Image_Editor_Resize_Top_RightInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Resize_Top_RightInputs, {
    locale?: "en";
}, {}>;
