export { nouns_avatar as "nouns.avatar" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_AvatarInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Avatar" |
* | * | "Avatars" |
*
* @param {Nouns_AvatarInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_avatar: ((inputs: Nouns_AvatarInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_AvatarInputs, {
    locale?: "en";
}, {}>;
