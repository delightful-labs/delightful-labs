export { transfers_destination_subject as "transfers.destination_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Destination_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Destination {subject}" |
*
* @param {Transfers_Destination_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_destination_subject: ((inputs: Transfers_Destination_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Destination_SubjectInputs, {
    locale?: "en";
}, {}>;
