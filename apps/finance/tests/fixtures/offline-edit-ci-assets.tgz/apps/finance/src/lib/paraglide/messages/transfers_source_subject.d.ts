export { transfers_source_subject as "transfers.source_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Source_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Source {subject}" |
*
* @param {Transfers_Source_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_source_subject: ((inputs: Transfers_Source_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Source_SubjectInputs, {
    locale?: "en";
}, {}>;
