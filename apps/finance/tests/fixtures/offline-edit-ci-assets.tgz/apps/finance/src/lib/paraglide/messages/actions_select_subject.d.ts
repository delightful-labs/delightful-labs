export { actions_select_subject as "actions.select_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Select_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Select {subject}" |
*
* @param {Actions_Select_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_select_subject: ((inputs: Actions_Select_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Select_SubjectInputs, {
    locale?: "en";
}, {}>;
