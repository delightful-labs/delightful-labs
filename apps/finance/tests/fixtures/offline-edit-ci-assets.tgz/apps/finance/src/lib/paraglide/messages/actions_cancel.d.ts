export { actions_cancel as "actions.cancel" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_CancelInputs = {};
/**
* | output |
* | --- |
* | "Cancel" |
*
* @param {Actions_CancelInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_cancel: ((inputs?: Actions_CancelInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_CancelInputs, {
    locale?: "en";
}, {}>;
