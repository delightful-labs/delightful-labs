export { accounts_archive_interrupted_saved as "accounts.archive_interrupted_saved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Archive_Interrupted_SavedInputs = {};
/**
* | output |
* | --- |
* | "The archive was saved locally before the operation ended." |
*
* @param {Accounts_Archive_Interrupted_SavedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_archive_interrupted_saved: ((inputs?: Accounts_Archive_Interrupted_SavedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Archive_Interrupted_SavedInputs, {
    locale?: "en";
}, {}>;
