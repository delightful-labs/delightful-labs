export { bank_log_unresolved as "bank.log_unresolved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Log_UnresolvedInputs = {};
/**
* | output |
* | --- |
* | "Import settlement unresolved" |
*
* @param {Bank_Log_UnresolvedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_log_unresolved: ((inputs?: Bank_Log_UnresolvedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Log_UnresolvedInputs, {
    locale?: "en";
}, {}>;
