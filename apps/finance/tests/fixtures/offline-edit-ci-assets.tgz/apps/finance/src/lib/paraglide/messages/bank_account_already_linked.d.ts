export { bank_account_already_linked as "bank.account_already_linked" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Account_Already_LinkedInputs = {};
/**
* | output |
* | --- |
* | "This local account is already linked to another provider account. Add a new account or select an unlinked account." |
*
* @param {Bank_Account_Already_LinkedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_account_already_linked: ((inputs?: Bank_Account_Already_LinkedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Account_Already_LinkedInputs, {
    locale?: "en";
}, {}>;
