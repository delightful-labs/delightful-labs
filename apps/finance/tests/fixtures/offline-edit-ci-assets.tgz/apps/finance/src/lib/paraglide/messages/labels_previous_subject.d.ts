export { labels_previous_subject as "labels.previous_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Previous_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Previous {subject}" |
*
* @param {Labels_Previous_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_previous_subject: ((inputs: Labels_Previous_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Previous_SubjectInputs, {
    locale?: "en";
}, {}>;
