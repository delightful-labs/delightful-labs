export { transfers_insufficient_accounts as "transfers.insufficient_accounts" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Insufficient_AccountsInputs = {};
/**
* | output |
* | --- |
* | "Add a second writable account to record a transfer." |
*
* @param {Transfers_Insufficient_AccountsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_insufficient_accounts: ((inputs?: Transfers_Insufficient_AccountsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Insufficient_AccountsInputs, {
    locale?: "en";
}, {}>;
