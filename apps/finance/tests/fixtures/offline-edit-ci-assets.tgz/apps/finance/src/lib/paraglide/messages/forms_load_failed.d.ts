export { forms_load_failed as "forms.load_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Load_FailedInputs = {};
/**
* | output |
* | --- |
* | "Editing information could not be loaded." |
*
* @param {Forms_Load_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_load_failed: ((inputs?: Forms_Load_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Load_FailedInputs, {
    locale?: "en";
}, {}>;
