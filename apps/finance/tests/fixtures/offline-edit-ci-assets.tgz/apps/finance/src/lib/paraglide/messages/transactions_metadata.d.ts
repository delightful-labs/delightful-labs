export { transactions_metadata as "transactions.metadata" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_MetadataInputs = {};
/**
* | output |
* | --- |
* | "Metadata" |
*
* @param {Transactions_MetadataInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_metadata: ((inputs?: Transactions_MetadataInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_MetadataInputs, {
    locale?: "en";
}, {}>;
