export { labels_password as "labels.password" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_PasswordInputs = {};
/**
* | output |
* | --- |
* | "Password" |
*
* @param {Labels_PasswordInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_password: ((inputs?: Labels_PasswordInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_PasswordInputs, {
    locale?: "en";
}, {}>;
