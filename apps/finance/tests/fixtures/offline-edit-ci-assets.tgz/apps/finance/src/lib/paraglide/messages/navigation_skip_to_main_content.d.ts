export { navigation_skip_to_main_content as "navigation.skip_to_main_content" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Navigation_Skip_To_Main_ContentInputs = {};
/**
* | output |
* | --- |
* | "Skip to main content" |
*
* @param {Navigation_Skip_To_Main_ContentInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const navigation_skip_to_main_content: ((inputs?: Navigation_Skip_To_Main_ContentInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Navigation_Skip_To_Main_ContentInputs, {
    locale?: "en";
}, {}>;
