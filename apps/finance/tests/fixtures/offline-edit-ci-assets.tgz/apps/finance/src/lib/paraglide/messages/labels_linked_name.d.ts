export { labels_linked_name as "labels.linked_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Linked_NameInputs = {
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Linked to {name}" |
*
* @param {Labels_Linked_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_linked_name: ((inputs: Labels_Linked_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Linked_NameInputs, {
    locale?: "en";
}, {}>;
