export { developer_menu as "developer.menu" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_MenuInputs = {};
/**
* | output |
* | --- |
* | "Developer menu" |
*
* @param {Developer_MenuInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_menu: ((inputs?: Developer_MenuInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_MenuInputs, {
    locale?: "en";
}, {}>;
