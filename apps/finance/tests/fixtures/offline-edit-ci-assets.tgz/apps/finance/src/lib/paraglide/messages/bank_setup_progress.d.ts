export { bank_setup_progress as "bank.setup_progress" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_ProgressInputs = {};
/**
* | output |
* | --- |
* | "Bank connection setup progress" |
*
* @param {Bank_Setup_ProgressInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_progress: ((inputs?: Bank_Setup_ProgressInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_ProgressInputs, {
    locale?: "en";
}, {}>;
