export { bank_setup_encrypt_body as "bank.setup_encrypt_body" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Encrypt_BodyInputs = {};
/**
* | output |
* | --- |
* | "Your passkey was created. Next, use it to encrypt a harmless sample. This checks encryption support without using your SimpleFIN token." |
*
* @param {Bank_Setup_Encrypt_BodyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_encrypt_body: ((inputs?: Bank_Setup_Encrypt_BodyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Encrypt_BodyInputs, {
    locale?: "en";
}, {}>;
