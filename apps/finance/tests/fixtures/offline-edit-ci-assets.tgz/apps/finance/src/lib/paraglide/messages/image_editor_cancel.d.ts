export { image_editor_cancel as "image_editor.cancel" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_CancelInputs = {};
/**
* | output |
* | --- |
* | "Cancel" |
*
* @param {Image_Editor_CancelInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_cancel: ((inputs?: Image_Editor_CancelInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_CancelInputs, {
    locale?: "en";
}, {}>;
