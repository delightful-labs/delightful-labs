export { archive_filter_all as "archive_filter.all" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Archive_Filter_AllInputs = {};
/**
* | output |
* | --- |
* | "All" |
*
* @param {Archive_Filter_AllInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const archive_filter_all: ((inputs?: Archive_Filter_AllInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Archive_Filter_AllInputs, {
    locale?: "en";
}, {}>;
