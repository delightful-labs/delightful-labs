export { actions_dismiss as "actions.dismiss" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_DismissInputs = {};
/**
* | output |
* | --- |
* | "Dismiss" |
*
* @param {Actions_DismissInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_dismiss: ((inputs?: Actions_DismissInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_DismissInputs, {
    locale?: "en";
}, {}>;
