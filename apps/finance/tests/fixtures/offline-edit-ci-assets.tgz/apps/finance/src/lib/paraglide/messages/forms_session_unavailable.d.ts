export { forms_session_unavailable as "forms.session_unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Session_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "Editing is unavailable until your session is ready. If your session changed, reopen this page." |
*
* @param {Forms_Session_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_session_unavailable: ((inputs?: Forms_Session_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Session_UnavailableInputs, {
    locale?: "en";
}, {}>;
