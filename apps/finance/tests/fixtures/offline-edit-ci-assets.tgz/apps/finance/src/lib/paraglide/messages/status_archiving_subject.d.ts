export { status_archiving_subject as "status.archiving_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Archiving_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Archiving {subject}…" |
*
* @param {Status_Archiving_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_archiving_subject: ((inputs: Status_Archiving_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Archiving_SubjectInputs, {
    locale?: "en";
}, {}>;
