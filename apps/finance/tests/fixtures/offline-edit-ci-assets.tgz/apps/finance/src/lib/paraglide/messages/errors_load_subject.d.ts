export { errors_load_subject as "errors.load_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Load_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Could not load {subject}." |
*
* @param {Errors_Load_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_load_subject: ((inputs: Errors_Load_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Load_SubjectInputs, {
    locale?: "en";
}, {}>;
