export { accounts_create_session_unavailable as "accounts.create_session_unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Create_Session_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "Account creation is unavailable until your session is ready. If your session changed, reopen this page." |
*
* @param {Accounts_Create_Session_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_create_session_unavailable: ((inputs?: Accounts_Create_Session_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Create_Session_UnavailableInputs, {
    locale?: "en";
}, {}>;
