export { labels_total_subject_amount as "labels.total_subject_amount" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Total_Subject_AmountInputs = {
    subject: NonNullable<unknown>;
    amount: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Total {subject}: {amount}" |
*
* @param {Labels_Total_Subject_AmountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_total_subject_amount: ((inputs: Labels_Total_Subject_AmountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Total_Subject_AmountInputs, {
    locale?: "en";
}, {}>;
