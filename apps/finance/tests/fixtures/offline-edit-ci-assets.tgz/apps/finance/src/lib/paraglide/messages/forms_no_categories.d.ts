export { forms_no_categories as "forms.no_categories" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_No_CategoriesInputs = {};
/**
* | output |
* | --- |
* | "No applicable category is available for this transaction." |
*
* @param {Forms_No_CategoriesInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_no_categories: ((inputs?: Forms_No_CategoriesInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_No_CategoriesInputs, {
    locale?: "en";
}, {}>;
