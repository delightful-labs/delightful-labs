export { errors_unexpected_description as "errors.unexpected_description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Unexpected_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "The page could not be loaded. Please try again." |
*
* @param {Errors_Unexpected_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_unexpected_description: ((inputs?: Errors_Unexpected_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Unexpected_DescriptionInputs, {
    locale?: "en";
}, {}>;
