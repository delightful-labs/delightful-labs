export { workspace_create_unresolved as "workspace.create_unresolved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Create_UnresolvedInputs = {};
/**
* | output |
* | --- |
* | "The save result is unknown. Retry to check the same workspace before issuing another write." |
*
* @param {Workspace_Create_UnresolvedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_create_unresolved: ((inputs?: Workspace_Create_UnresolvedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Create_UnresolvedInputs, {
    locale?: "en";
}, {}>;
