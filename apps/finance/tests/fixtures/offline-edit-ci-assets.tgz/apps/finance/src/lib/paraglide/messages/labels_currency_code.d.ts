export { labels_currency_code as "labels.currency_code" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Currency_CodeInputs = {
    code: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Currency: {code}" |
*
* @param {Labels_Currency_CodeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_currency_code: ((inputs: Labels_Currency_CodeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Currency_CodeInputs, {
    locale?: "en";
}, {}>;
