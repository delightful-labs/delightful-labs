export { workspace_settings_saved as "workspace.settings_saved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Settings_SavedInputs = {};
/**
* | output |
* | --- |
* | "Workspace settings saved." |
*
* @param {Workspace_Settings_SavedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_settings_saved: ((inputs?: Workspace_Settings_SavedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Settings_SavedInputs, {
    locale?: "en";
}, {}>;
