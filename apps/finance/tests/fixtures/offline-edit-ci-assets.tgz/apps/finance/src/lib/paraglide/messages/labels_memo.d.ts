export { labels_memo as "labels.memo" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_MemoInputs = {};
/**
* | output |
* | --- |
* | "Memo (additional notes)" |
*
* @param {Labels_MemoInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_memo: ((inputs?: Labels_MemoInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_MemoInputs, {
    locale?: "en";
}, {}>;
