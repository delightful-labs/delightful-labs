export { labels_currency as "labels.currency" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_CurrencyInputs = {};
/**
* | output |
* | --- |
* | "Currency" |
*
* @param {Labels_CurrencyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_currency: ((inputs?: Labels_CurrencyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_CurrencyInputs, {
    locale?: "en";
}, {}>;
