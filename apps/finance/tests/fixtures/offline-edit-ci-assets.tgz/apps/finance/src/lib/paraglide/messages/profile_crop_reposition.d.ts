export { profile_crop_reposition as "profile.crop_reposition" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_RepositionInputs = {};
/**
* | output |
* | --- |
* | "Move crop area with arrow keys" |
*
* @param {Profile_Crop_RepositionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_reposition: ((inputs?: Profile_Crop_RepositionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_RepositionInputs, {
    locale?: "en";
}, {}>;
