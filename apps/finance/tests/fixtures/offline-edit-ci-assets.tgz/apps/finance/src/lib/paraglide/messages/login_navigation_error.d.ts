export { login_navigation_error as "login.navigation_error" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Login_Navigation_ErrorInputs = {};
/**
* | output |
* | --- |
* | "Your account was restored, but the destination could not be opened. Try again or use the navigation links." |
*
* @param {Login_Navigation_ErrorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const login_navigation_error: ((inputs?: Login_Navigation_ErrorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Login_Navigation_ErrorInputs, {
    locale?: "en";
}, {}>;
