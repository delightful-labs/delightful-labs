export { labels_subject_recovery as "labels.subject_recovery" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_RecoveryInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} recovery" |
*
* @param {Labels_Subject_RecoveryInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_recovery: ((inputs: Labels_Subject_RecoveryInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_RecoveryInputs, {
    locale?: "en";
}, {}>;
