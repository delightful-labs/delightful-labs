export { actions_open_subject as "actions.open_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Open_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Open {subject}" |
*
* @param {Actions_Open_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_open_subject: ((inputs: Actions_Open_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Open_SubjectInputs, {
    locale?: "en";
}, {}>;
