export { actions_remove_name as "actions.remove_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Remove_NameInputs = {
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Remove {name}" |
*
* @param {Actions_Remove_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_remove_name: ((inputs: Actions_Remove_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Remove_NameInputs, {
    locale?: "en";
}, {}>;
