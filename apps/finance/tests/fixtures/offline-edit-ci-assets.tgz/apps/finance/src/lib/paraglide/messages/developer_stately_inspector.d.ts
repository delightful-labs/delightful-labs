export { developer_stately_inspector as "developer.stately_inspector" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_Stately_InspectorInputs = {};
/**
* | output |
* | --- |
* | "Stately Inspector" |
*
* @param {Developer_Stately_InspectorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_stately_inspector: ((inputs?: Developer_Stately_InspectorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_Stately_InspectorInputs, {
    locale?: "en";
}, {}>;
