export { labels_more_subjects as "labels.more_subjects" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_More_SubjectsInputs = {
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "More {subjects}" |
*
* @param {Labels_More_SubjectsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_more_subjects: ((inputs: Labels_More_SubjectsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_More_SubjectsInputs, {
    locale?: "en";
}, {}>;
