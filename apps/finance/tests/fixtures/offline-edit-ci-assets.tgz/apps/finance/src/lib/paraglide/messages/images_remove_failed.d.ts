export { images_remove_failed as "images.remove_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Remove_FailedInputs = {};
/**
* | output |
* | --- |
* | "This image could not be removed. Try again." |
*
* @param {Images_Remove_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_remove_failed: ((inputs?: Images_Remove_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Remove_FailedInputs, {
    locale?: "en";
}, {}>;
