export { archive_filter_active as "archive_filter.active" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Archive_Filter_ActiveInputs = {};
/**
* | output |
* | --- |
* | "Default (not archived)" |
*
* @param {Archive_Filter_ActiveInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const archive_filter_active: ((inputs?: Archive_Filter_ActiveInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Archive_Filter_ActiveInputs, {
    locale?: "en";
}, {}>;
