export { bank_setup_encrypt_action as "bank.setup_encrypt_action" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Encrypt_ActionInputs = {};
/**
* | output |
* | --- |
* | "Test encryption with my passkey" |
*
* @param {Bank_Setup_Encrypt_ActionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_encrypt_action: ((inputs?: Bank_Setup_Encrypt_ActionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Encrypt_ActionInputs, {
    locale?: "en";
}, {}>;
