export { defaults_categories_other_expense as "defaults.categories.other_expense" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_Other_ExpenseInputs = {};
/**
* | output |
* | --- |
* | "Other expense" |
*
* @param {Defaults_Categories_Other_ExpenseInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_other_expense: ((inputs?: Defaults_Categories_Other_ExpenseInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_Other_ExpenseInputs, {
    locale?: "en";
}, {}>;
