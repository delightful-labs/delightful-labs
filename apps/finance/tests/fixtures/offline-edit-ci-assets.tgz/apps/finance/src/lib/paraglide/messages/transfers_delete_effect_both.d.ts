export { transfers_delete_effect_both as "transfers.delete_effect_both" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Delete_Effect_BothInputs = {};
/**
* | output |
* | --- |
* | "Both transactions and their transfer link will be deleted. The transfer will no longer appear in your records." |
*
* @param {Transfers_Delete_Effect_BothInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_delete_effect_both: ((inputs?: Transfers_Delete_Effect_BothInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Delete_Effect_BothInputs, {
    locale?: "en";
}, {}>;
