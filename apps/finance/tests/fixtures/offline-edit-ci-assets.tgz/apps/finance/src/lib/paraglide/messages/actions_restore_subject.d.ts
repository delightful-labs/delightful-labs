export { actions_restore_subject as "actions.restore_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Restore_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Restore {subject}" |
*
* @param {Actions_Restore_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_restore_subject: ((inputs: Actions_Restore_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Restore_SubjectInputs, {
    locale?: "en";
}, {}>;
