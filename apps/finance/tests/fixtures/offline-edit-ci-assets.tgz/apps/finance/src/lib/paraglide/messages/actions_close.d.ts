export { actions_close as "actions.close" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_CloseInputs = {};
/**
* | output |
* | --- |
* | "Close" |
*
* @param {Actions_CloseInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_close: ((inputs?: Actions_CloseInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_CloseInputs, {
    locale?: "en";
}, {}>;
