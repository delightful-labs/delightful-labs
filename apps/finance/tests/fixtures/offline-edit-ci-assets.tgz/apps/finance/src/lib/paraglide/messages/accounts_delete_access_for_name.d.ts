export { accounts_delete_access_for_name as "accounts.delete_access_for_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Delete_Access_For_NameInputs = {
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Allow {name} to delete transactions" |
*
* @param {Accounts_Delete_Access_For_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_delete_access_for_name: ((inputs: Accounts_Delete_Access_For_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Delete_Access_For_NameInputs, {
    locale?: "en";
}, {}>;
