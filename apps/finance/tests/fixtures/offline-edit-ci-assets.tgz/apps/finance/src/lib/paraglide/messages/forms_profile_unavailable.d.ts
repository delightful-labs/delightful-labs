export { forms_profile_unavailable as "forms.profile_unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Profile_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "Your profile is unavailable for editing." |
*
* @param {Forms_Profile_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_profile_unavailable: ((inputs?: Forms_Profile_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Profile_UnavailableInputs, {
    locale?: "en";
}, {}>;
