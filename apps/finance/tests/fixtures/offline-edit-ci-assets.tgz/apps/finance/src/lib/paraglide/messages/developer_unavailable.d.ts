export { developer_unavailable as "developer.unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "Unavailable" |
*
* @param {Developer_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_unavailable: ((inputs?: Developer_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_UnavailableInputs, {
    locale?: "en";
}, {}>;
