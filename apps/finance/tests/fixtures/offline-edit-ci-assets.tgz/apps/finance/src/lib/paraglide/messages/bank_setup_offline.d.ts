export { bank_setup_offline as "bank.setup_offline" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_OfflineInputs = {};
/**
* | output |
* | --- |
* | "Bank sync setup is not available offline. Connect to the internet to continue." |
*
* @param {Bank_Setup_OfflineInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_offline: ((inputs?: Bank_Setup_OfflineInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_OfflineInputs, {
    locale?: "en";
}, {}>;
