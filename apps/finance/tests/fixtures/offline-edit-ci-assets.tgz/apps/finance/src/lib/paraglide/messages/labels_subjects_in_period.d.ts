export { labels_subjects_in_period as "labels.subjects_in_period" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subjects_In_PeriodInputs = {
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subjects} in this period" |
*
* @param {Labels_Subjects_In_PeriodInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subjects_in_period: ((inputs: Labels_Subjects_In_PeriodInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subjects_In_PeriodInputs, {
    locale?: "en";
}, {}>;
