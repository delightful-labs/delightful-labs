export { actions_show_subject as "actions.show_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Show_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Show {subject}" |
*
* @param {Actions_Show_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_show_subject: ((inputs: Actions_Show_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Show_SubjectInputs, {
    locale?: "en";
}, {}>;
