export { status_saved_subject_name as "status.saved_subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Saved_Subject_NameInputs = {
    subject: NonNullable<unknown>;
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} {name} saved." |
*
* @param {Status_Saved_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_saved_subject_name: ((inputs: Status_Saved_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Saved_Subject_NameInputs, {
    locale?: "en";
}, {}>;
