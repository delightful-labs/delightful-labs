export { actions_search_subject as "actions.search_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Search_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Search {subject}" |
*
* @param {Actions_Search_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_search_subject: ((inputs: Actions_Search_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Search_SubjectInputs, {
    locale?: "en";
}, {}>;
