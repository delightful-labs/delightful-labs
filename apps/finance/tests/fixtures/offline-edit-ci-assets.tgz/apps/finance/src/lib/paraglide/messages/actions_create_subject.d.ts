export { actions_create_subject as "actions.create_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Create_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Create {subject}" |
*
* @param {Actions_Create_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_create_subject: ((inputs: Actions_Create_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Create_SubjectInputs, {
    locale?: "en";
}, {}>;
