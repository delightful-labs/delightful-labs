export { labels_calculated_balance as "labels.calculated_balance" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Calculated_BalanceInputs = {};
/**
* | output |
* | --- |
* | "Calculated balance" |
*
* @param {Labels_Calculated_BalanceInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_calculated_balance: ((inputs?: Labels_Calculated_BalanceInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Calculated_BalanceInputs, {
    locale?: "en";
}, {}>;
