export { workspace_integrity_failed as "workspace.integrity_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Integrity_FailedInputs = {};
/**
* | output |
* | --- |
* | "Required workspace records could not be verified. Retry to check again." |
*
* @param {Workspace_Integrity_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_integrity_failed: ((inputs?: Workspace_Integrity_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Integrity_FailedInputs, {
    locale?: "en";
}, {}>;
