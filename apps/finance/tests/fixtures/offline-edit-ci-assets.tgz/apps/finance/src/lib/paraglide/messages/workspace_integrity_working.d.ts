export { workspace_integrity_working as "workspace.integrity_working" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Integrity_WorkingInputs = {};
/**
* | output |
* | --- |
* | "Checking required workspace records…" |
*
* @param {Workspace_Integrity_WorkingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_integrity_working: ((inputs?: Workspace_Integrity_WorkingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Integrity_WorkingInputs, {
    locale?: "en";
}, {}>;
