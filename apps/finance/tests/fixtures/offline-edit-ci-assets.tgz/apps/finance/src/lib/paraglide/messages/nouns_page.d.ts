export { nouns_page as "nouns.page" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_PageInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Page" |
* | * | "Pages" |
*
* @param {Nouns_PageInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_page: ((inputs: Nouns_PageInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_PageInputs, {
    locale?: "en";
}, {}>;
