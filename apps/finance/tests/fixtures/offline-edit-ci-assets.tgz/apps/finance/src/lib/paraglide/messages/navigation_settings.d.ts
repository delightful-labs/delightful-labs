export { navigation_settings as "navigation.settings" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Navigation_SettingsInputs = {};
/**
* | output |
* | --- |
* | "Settings" |
*
* @param {Navigation_SettingsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const navigation_settings: ((inputs?: Navigation_SettingsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Navigation_SettingsInputs, {
    locale?: "en";
}, {}>;
