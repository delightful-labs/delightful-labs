export { developer_account_id as "developer.account_id" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_Account_IdInputs = {};
/**
* | output |
* | --- |
* | "Current account ID" |
*
* @param {Developer_Account_IdInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_account_id: ((inputs?: Developer_Account_IdInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_Account_IdInputs, {
    locale?: "en";
}, {}>;
