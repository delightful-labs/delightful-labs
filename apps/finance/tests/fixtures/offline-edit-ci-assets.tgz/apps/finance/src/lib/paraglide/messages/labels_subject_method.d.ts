export { labels_subject_method as "labels.subject_method" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_MethodInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} method" |
*
* @param {Labels_Subject_MethodInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_method: ((inputs: Labels_Subject_MethodInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_MethodInputs, {
    locale?: "en";
}, {}>;
