export { status_loading as "status.loading" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_LoadingInputs = {};
/**
* | output |
* | --- |
* | "Loading…" |
*
* @param {Status_LoadingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_loading: ((inputs?: Status_LoadingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_LoadingInputs, {
    locale?: "en";
}, {}>;
