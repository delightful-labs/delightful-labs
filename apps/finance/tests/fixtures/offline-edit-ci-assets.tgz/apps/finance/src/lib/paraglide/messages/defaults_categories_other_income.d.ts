export { defaults_categories_other_income as "defaults.categories.other_income" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_Other_IncomeInputs = {};
/**
* | output |
* | --- |
* | "Other income" |
*
* @param {Defaults_Categories_Other_IncomeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_other_income: ((inputs?: Defaults_Categories_Other_IncomeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_Other_IncomeInputs, {
    locale?: "en";
}, {}>;
