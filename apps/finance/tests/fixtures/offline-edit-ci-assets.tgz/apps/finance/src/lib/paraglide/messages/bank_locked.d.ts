export { bank_locked as "bank.locked" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_LockedInputs = {};
/**
* | output |
* | --- |
* | "Locked. Each action requires your original passkey." |
*
* @param {Bank_LockedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_locked: ((inputs?: Bank_LockedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_LockedInputs, {
    locale?: "en";
}, {}>;
