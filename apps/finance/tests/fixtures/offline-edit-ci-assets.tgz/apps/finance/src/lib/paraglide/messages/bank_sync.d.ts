export { bank_sync as "bank.sync" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_SyncInputs = {};
/**
* | output |
* | --- |
* | "Sync now (last 90 days)" |
*
* @param {Bank_SyncInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_sync: ((inputs?: Bank_SyncInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_SyncInputs, {
    locale?: "en";
}, {}>;
