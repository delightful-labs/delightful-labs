export { developer_jazz_app_id as "developer.jazz_app_id" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_Jazz_App_IdInputs = {};
/**
* | output |
* | --- |
* | "Jazz app ID" |
*
* @param {Developer_Jazz_App_IdInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_jazz_app_id: ((inputs?: Developer_Jazz_App_IdInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_Jazz_App_IdInputs, {
    locale?: "en";
}, {}>;
