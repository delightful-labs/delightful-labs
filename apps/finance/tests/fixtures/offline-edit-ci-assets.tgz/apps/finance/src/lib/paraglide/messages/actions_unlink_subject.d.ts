export { actions_unlink_subject as "actions.unlink_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Unlink_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Unlink {subject}" |
*
* @param {Actions_Unlink_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_unlink_subject: ((inputs: Actions_Unlink_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Unlink_SubjectInputs, {
    locale?: "en";
}, {}>;
