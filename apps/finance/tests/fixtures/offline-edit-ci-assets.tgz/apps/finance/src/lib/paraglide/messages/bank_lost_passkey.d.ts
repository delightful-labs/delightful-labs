export { bank_lost_passkey as "bank.lost_passkey" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Lost_PasskeyInputs = {};
/**
* | output |
* | --- |
* | "Lost passkey?" |
*
* @param {Bank_Lost_PasskeyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_lost_passkey: ((inputs?: Bank_Lost_PasskeyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Lost_PasskeyInputs, {
    locale?: "en";
}, {}>;
