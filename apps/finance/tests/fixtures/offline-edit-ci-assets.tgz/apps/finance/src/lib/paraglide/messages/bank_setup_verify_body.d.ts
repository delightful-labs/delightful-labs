export { bank_setup_verify_body as "bank.setup_verify_body" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Verify_BodyInputs = {};
/**
* | output |
* | --- |
* | "The sample is encrypted. Use the same passkey again to confirm it can unlock the sample. This separate check proves the connection can be recovered later." |
*
* @param {Bank_Setup_Verify_BodyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_verify_body: ((inputs?: Bank_Setup_Verify_BodyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Verify_BodyInputs, {
    locale?: "en";
}, {}>;
