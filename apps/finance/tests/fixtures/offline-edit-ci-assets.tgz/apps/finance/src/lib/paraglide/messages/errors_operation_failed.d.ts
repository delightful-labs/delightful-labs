export { errors_operation_failed as "errors.operation_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Operation_FailedInputs = {};
/**
* | output |
* | --- |
* | "Couldn’t complete the request. Please try again." |
*
* @param {Errors_Operation_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_operation_failed: ((inputs?: Errors_Operation_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Operation_FailedInputs, {
    locale?: "en";
}, {}>;
