export { actions_imported as "actions.imported" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_ImportedInputs = {};
/**
* | output |
* | --- |
* | "Imported" |
*
* @param {Actions_ImportedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_imported: ((inputs?: Actions_ImportedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_ImportedInputs, {
    locale?: "en";
}, {}>;
