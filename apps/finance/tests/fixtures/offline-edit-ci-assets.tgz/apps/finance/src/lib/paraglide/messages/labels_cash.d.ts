export { labels_cash as "labels.cash" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_CashInputs = {};
/**
* | output |
* | --- |
* | "Cash" |
*
* @param {Labels_CashInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_cash: ((inputs?: Labels_CashInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_CashInputs, {
    locale?: "en";
}, {}>;
