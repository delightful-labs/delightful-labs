export { labels_actions as "labels.actions" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_ActionsInputs = {};
/**
* | output |
* | --- |
* | "Actions" |
*
* @param {Labels_ActionsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_actions: ((inputs?: Labels_ActionsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_ActionsInputs, {
    locale?: "en";
}, {}>;
