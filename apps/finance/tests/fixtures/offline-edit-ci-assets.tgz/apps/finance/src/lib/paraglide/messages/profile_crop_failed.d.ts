export { profile_crop_failed as "profile.crop_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_FailedInputs = {};
/**
* | output |
* | --- |
* | "This image could not be cropped. Choose another image and try again." |
*
* @param {Profile_Crop_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_failed: ((inputs?: Profile_Crop_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_FailedInputs, {
    locale?: "en";
}, {}>;
