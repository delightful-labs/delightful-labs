export { bank_system_account_name as "bank.system_account_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_System_Account_NameInputs = {};
/**
* | output |
* | --- |
* | "Bank Sync" |
*
* @param {Bank_System_Account_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_system_account_name: ((inputs?: Bank_System_Account_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_System_Account_NameInputs, {
    locale?: "en";
}, {}>;
