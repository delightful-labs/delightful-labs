export { profile_crop_resize_bottom_left as "profile.crop_resize_bottom_left" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_Resize_Bottom_LeftInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from bottom left corner" |
*
* @param {Profile_Crop_Resize_Bottom_LeftInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_resize_bottom_left: ((inputs?: Profile_Crop_Resize_Bottom_LeftInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_Resize_Bottom_LeftInputs, {
    locale?: "en";
}, {}>;
