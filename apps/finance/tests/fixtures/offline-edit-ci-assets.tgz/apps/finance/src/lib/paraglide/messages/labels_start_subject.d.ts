export { labels_start_subject as "labels.start_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Start_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Start {subject}" |
*
* @param {Labels_Start_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_start_subject: ((inputs: Labels_Start_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Start_SubjectInputs, {
    locale?: "en";
}, {}>;
