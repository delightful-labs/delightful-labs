export { navigation_login as "navigation.login" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Navigation_LoginInputs = {};
/**
* | output |
* | --- |
* | "Login" |
*
* @param {Navigation_LoginInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const navigation_login: ((inputs?: Navigation_LoginInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Navigation_LoginInputs, {
    locale?: "en";
}, {}>;
