export { nouns_date as "nouns.date" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_DateInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Date" |
* | * | "Dates" |
*
* @param {Nouns_DateInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_date: ((inputs: Nouns_DateInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_DateInputs, {
    locale?: "en";
}, {}>;
