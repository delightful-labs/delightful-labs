export { nouns_category as "nouns.category" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_CategoryInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Category" |
* | * | "Categories" |
*
* @param {Nouns_CategoryInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_category: ((inputs: Nouns_CategoryInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_CategoryInputs, {
    locale?: "en";
}, {}>;
