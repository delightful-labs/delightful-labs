export { labels_subject_number as "labels.subject_number" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_NumberInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} number" |
*
* @param {Labels_Subject_NumberInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_number: ((inputs: Labels_Subject_NumberInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_NumberInputs, {
    locale?: "en";
}, {}>;
