export { image_editor_resize_top_left as "image_editor.resize_top_left" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Resize_Top_LeftInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from top left corner" |
*
* @param {Image_Editor_Resize_Top_LeftInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_resize_top_left: ((inputs?: Image_Editor_Resize_Top_LeftInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Resize_Top_LeftInputs, {
    locale?: "en";
}, {}>;
