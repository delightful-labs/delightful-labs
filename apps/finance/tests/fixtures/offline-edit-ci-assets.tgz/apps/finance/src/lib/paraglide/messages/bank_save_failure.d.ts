export { bank_save_failure as "bank.save_failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Save_FailureInputs = {};
/**
* | output |
* | --- |
* | "The token was consumed but the encrypted connection was not saved. Revoke this connection at SimpleFIN and reconnect with a new token." |
*
* @param {Bank_Save_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_save_failure: ((inputs?: Bank_Save_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Save_FailureInputs, {
    locale?: "en";
}, {}>;
