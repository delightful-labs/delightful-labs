export { navigation_overview as "navigation.overview" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Navigation_OverviewInputs = {};
/**
* | output |
* | --- |
* | "Overview" |
*
* @param {Navigation_OverviewInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const navigation_overview: ((inputs?: Navigation_OverviewInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Navigation_OverviewInputs, {
    locale?: "en";
}, {}>;
