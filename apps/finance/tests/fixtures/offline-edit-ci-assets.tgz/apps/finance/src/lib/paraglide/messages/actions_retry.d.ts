export { actions_retry as "actions.retry" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_RetryInputs = {};
/**
* | output |
* | --- |
* | "Try again" |
*
* @param {Actions_RetryInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_retry: ((inputs?: Actions_RetryInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_RetryInputs, {
    locale?: "en";
}, {}>;
