export { bank_title as "bank.title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_TitleInputs = {};
/**
* | output |
* | --- |
* | "Bank sync" |
*
* @param {Bank_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_title: ((inputs?: Bank_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_TitleInputs, {
    locale?: "en";
}, {}>;
