export { transactions_save_unresolved as "transactions.save_unresolved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Save_UnresolvedInputs = {};
/**
* | output |
* | --- |
* | "The save result is uncertain. Save again to verify the same records when connected before issuing another write. Keep this form open until the result is reso..." |
*
* @param {Transactions_Save_UnresolvedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_save_unresolved: ((inputs?: Transactions_Save_UnresolvedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Save_UnresolvedInputs, {
    locale?: "en";
}, {}>;
