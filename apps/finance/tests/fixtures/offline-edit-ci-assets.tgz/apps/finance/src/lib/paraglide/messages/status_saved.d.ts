export { status_saved as "status.saved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_SavedInputs = {};
/**
* | output |
* | --- |
* | "Saved" |
*
* @param {Status_SavedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_saved: ((inputs?: Status_SavedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_SavedInputs, {
    locale?: "en";
}, {}>;
