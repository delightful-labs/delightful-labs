export { forms_validation_error as "forms.validation_error" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Validation_ErrorInputs = {};
/**
* | output |
* | --- |
* | "Check the form and try again." |
*
* @param {Forms_Validation_ErrorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_validation_error: ((inputs?: Forms_Validation_ErrorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Validation_ErrorInputs, {
    locale?: "en";
}, {}>;
