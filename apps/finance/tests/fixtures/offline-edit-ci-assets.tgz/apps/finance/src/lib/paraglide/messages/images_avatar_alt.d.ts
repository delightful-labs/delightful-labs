export { images_avatar_alt as "images.avatar_alt" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Avatar_AltInputs = {};
/**
* | output |
* | --- |
* | "Your avatar" |
*
* @param {Images_Avatar_AltInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_avatar_alt: ((inputs?: Images_Avatar_AltInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Avatar_AltInputs, {
    locale?: "en";
}, {}>;
