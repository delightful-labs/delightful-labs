export { labels_with_password as "labels.with_password" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_With_PasswordInputs = {};
/**
* | output |
* | --- |
* | "With a password" |
*
* @param {Labels_With_PasswordInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_with_password: ((inputs?: Labels_With_PasswordInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_With_PasswordInputs, {
    locale?: "en";
}, {}>;
