export { transfers_incompatible as "transfers.incompatible" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_IncompatibleInputs = {};
/**
* | output |
* | --- |
* | "Choose two different accounts in the same workspace." |
*
* @param {Transfers_IncompatibleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_incompatible: ((inputs?: Transfers_IncompatibleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_IncompatibleInputs, {
    locale?: "en";
}, {}>;
