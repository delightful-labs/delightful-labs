export { image_editor_exporting as "image_editor.exporting" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_ExportingInputs = {};
/**
* | output |
* | --- |
* | "Preparing edited image…" |
*
* @param {Image_Editor_ExportingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_exporting: ((inputs?: Image_Editor_ExportingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_ExportingInputs, {
    locale?: "en";
}, {}>;
