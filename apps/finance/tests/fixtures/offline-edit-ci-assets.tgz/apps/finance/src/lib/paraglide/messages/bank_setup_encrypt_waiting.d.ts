export { bank_setup_encrypt_waiting as "bank.setup_encrypt_waiting" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Encrypt_WaitingInputs = {};
/**
* | output |
* | --- |
* | "Approve the passkey prompt to encrypt the sample. Your setup token has not been claimed." |
*
* @param {Bank_Setup_Encrypt_WaitingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_encrypt_waiting: ((inputs?: Bank_Setup_Encrypt_WaitingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Encrypt_WaitingInputs, {
    locale?: "en";
}, {}>;
