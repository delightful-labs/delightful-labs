export { transfers_delete_saved_selected as "transfers.delete_saved_selected" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Delete_Saved_SelectedInputs = {};
/**
* | output |
* | --- |
* | "This transaction was unlinked and deleted on this device. The other transaction remains." |
*
* @param {Transfers_Delete_Saved_SelectedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_delete_saved_selected: ((inputs?: Transfers_Delete_Saved_SelectedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Delete_Saved_SelectedInputs, {
    locale?: "en";
}, {}>;
