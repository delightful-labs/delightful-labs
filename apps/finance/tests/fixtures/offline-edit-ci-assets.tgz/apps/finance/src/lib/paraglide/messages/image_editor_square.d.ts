export { image_editor_square as "image_editor.square" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_SquareInputs = {};
/**
* | output |
* | --- |
* | "Square" |
*
* @param {Image_Editor_SquareInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_square: ((inputs?: Image_Editor_SquareInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_SquareInputs, {
    locale?: "en";
}, {}>;
