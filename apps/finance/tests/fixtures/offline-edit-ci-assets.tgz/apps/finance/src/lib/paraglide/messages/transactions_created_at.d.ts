export { transactions_created_at as "transactions.created_at" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Created_AtInputs = {};
/**
* | output |
* | --- |
* | "Created at" |
*
* @param {Transactions_Created_AtInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_created_at: ((inputs?: Transactions_Created_AtInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Created_AtInputs, {
    locale?: "en";
}, {}>;
