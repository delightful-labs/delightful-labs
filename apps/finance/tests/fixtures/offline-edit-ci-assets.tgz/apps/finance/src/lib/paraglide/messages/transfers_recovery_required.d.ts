export { transfers_recovery_required as "transfers.recovery_required" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Recovery_RequiredInputs = {};
/**
* | output |
* | --- |
* | "The transfer is incomplete. Review the transactions before retrying." |
*
* @param {Transfers_Recovery_RequiredInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_recovery_required: ((inputs?: Transfers_Recovery_RequiredInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Recovery_RequiredInputs, {
    locale?: "en";
}, {}>;
