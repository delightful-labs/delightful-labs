export { pwa_update_failed as "pwa_update.failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Pwa_Update_FailedInputs = {};
/**
* | output |
* | --- |
* | "The update could not be completed. You can try again." |
*
* @param {Pwa_Update_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const pwa_update_failed: ((inputs?: Pwa_Update_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Pwa_Update_FailedInputs, {
    locale?: "en";
}, {}>;
