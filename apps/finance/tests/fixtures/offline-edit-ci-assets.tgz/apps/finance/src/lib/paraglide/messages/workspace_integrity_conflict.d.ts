export { workspace_integrity_conflict as "workspace.integrity_conflict" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Integrity_ConflictInputs = {};
/**
* | output |
* | --- |
* | "Required workspace records conflict. No records were overwritten." |
*
* @param {Workspace_Integrity_ConflictInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_integrity_conflict: ((inputs?: Workspace_Integrity_ConflictInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Integrity_ConflictInputs, {
    locale?: "en";
}, {}>;
