export { bank_mapping_failure as "bank.mapping_failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Mapping_FailureInputs = {};
/**
* | output |
* | --- |
* | "A mapped account is archived, unavailable or ambiguous. Discover accounts and map each provider account to an active local account, then retry manually." |
*
* @param {Bank_Mapping_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_mapping_failure: ((inputs?: Bank_Mapping_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Mapping_FailureInputs, {
    locale?: "en";
}, {}>;
