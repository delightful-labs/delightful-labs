export { actions_archive_button as "actions.archive_button" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Archive_ButtonInputs = {};
/**
* | output |
* | --- |
* | "Archive" |
*
* @param {Actions_Archive_ButtonInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_archive_button: ((inputs?: Actions_Archive_ButtonInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Archive_ButtonInputs, {
    locale?: "en";
}, {}>;
