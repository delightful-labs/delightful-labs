export { nouns_permission as "nouns.permission" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_PermissionInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Permission" |
* | * | "Permissions" |
*
* @param {Nouns_PermissionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_permission: ((inputs: Nouns_PermissionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_PermissionInputs, {
    locale?: "en";
}, {}>;
