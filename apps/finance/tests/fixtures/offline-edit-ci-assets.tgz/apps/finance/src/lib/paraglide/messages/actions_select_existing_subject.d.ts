export { actions_select_existing_subject as "actions.select_existing_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Select_Existing_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Select existing {subject}" |
*
* @param {Actions_Select_Existing_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_select_existing_subject: ((inputs: Actions_Select_Existing_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Select_Existing_SubjectInputs, {
    locale?: "en";
}, {}>;
