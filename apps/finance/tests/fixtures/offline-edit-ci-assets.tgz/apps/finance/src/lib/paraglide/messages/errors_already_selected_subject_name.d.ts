export { errors_already_selected_subject_name as "errors.already_selected_subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Already_Selected_Subject_NameInputs = {
    subject: NonNullable<unknown>;
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} {name} is already selected." |
*
* @param {Errors_Already_Selected_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_already_selected_subject_name: ((inputs: Errors_Already_Selected_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Already_Selected_Subject_NameInputs, {
    locale?: "en";
}, {}>;
