export { forms_select_subject as "forms.select_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Select_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Select an option for {subject}" |
*
* @param {Forms_Select_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_select_subject: ((inputs: Forms_Select_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Select_SubjectInputs, {
    locale?: "en";
}, {}>;
