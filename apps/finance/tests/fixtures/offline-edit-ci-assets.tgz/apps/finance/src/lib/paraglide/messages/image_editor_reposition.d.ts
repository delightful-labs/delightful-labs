export { image_editor_reposition as "image_editor.reposition" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_RepositionInputs = {};
/**
* | output |
* | --- |
* | "Move crop area with arrow keys" |
*
* @param {Image_Editor_RepositionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_reposition: ((inputs?: Image_Editor_RepositionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_RepositionInputs, {
    locale?: "en";
}, {}>;
