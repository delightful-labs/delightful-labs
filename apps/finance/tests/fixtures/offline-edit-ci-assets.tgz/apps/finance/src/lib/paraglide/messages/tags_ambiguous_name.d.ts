export { tags_ambiguous_name as "tags.ambiguous_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Tags_Ambiguous_NameInputs = {};
/**
* | output |
* | --- |
* | "More than one active tag has this name for this transaction type. Resolve the duplicate tags before saving." |
*
* @param {Tags_Ambiguous_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const tags_ambiguous_name: ((inputs?: Tags_Ambiguous_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Tags_Ambiguous_NameInputs, {
    locale?: "en";
}, {}>;
