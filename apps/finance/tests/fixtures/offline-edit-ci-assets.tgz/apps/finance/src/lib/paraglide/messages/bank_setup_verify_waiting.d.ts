export { bank_setup_verify_waiting as "bank.setup_verify_waiting" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Verify_WaitingInputs = {};
/**
* | output |
* | --- |
* | "Approve the passkey prompt to unlock the sample. Your setup token has not been claimed." |
*
* @param {Bank_Setup_Verify_WaitingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_verify_waiting: ((inputs?: Bank_Setup_Verify_WaitingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Verify_WaitingInputs, {
    locale?: "en";
}, {}>;
