export { images_formats as "images.formats" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_FormatsInputs = {};
/**
* | output |
* | --- |
* | "JPEG, PNG, or WebP images." |
*
* @param {Images_FormatsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_formats: ((inputs?: Images_FormatsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_FormatsInputs, {
    locale?: "en";
}, {}>;
