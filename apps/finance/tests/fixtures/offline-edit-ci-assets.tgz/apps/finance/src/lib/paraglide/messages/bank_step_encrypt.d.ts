export { bank_step_encrypt as "bank.step_encrypt" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Step_EncryptInputs = {};
/**
* | output |
* | --- |
* | "Test encryption" |
*
* @param {Bank_Step_EncryptInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_step_encrypt: ((inputs?: Bank_Step_EncryptInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Step_EncryptInputs, {
    locale?: "en";
}, {}>;
