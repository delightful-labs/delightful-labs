export { labels_no_subject as "labels.no_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_No_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "No {subject}" |
*
* @param {Labels_No_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_no_subject: ((inputs: Labels_No_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_No_SubjectInputs, {
    locale?: "en";
}, {}>;
