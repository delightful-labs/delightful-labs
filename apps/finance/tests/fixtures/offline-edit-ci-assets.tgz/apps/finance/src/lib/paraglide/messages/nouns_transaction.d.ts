export { nouns_transaction as "nouns.transaction" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_TransactionInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Transaction" |
* | * | "Transactions" |
*
* @param {Nouns_TransactionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_transaction: ((inputs: Nouns_TransactionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_TransactionInputs, {
    locale?: "en";
}, {}>;
