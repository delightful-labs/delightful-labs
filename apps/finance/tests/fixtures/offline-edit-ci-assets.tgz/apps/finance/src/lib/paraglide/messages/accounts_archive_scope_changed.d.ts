export { accounts_archive_scope_changed as "accounts.archive_scope_changed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Archive_Scope_ChangedInputs = {};
/**
* | output |
* | --- |
* | "The workspace or access changed before archiving completed." |
*
* @param {Accounts_Archive_Scope_ChangedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_archive_scope_changed: ((inputs?: Accounts_Archive_Scope_ChangedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Archive_Scope_ChangedInputs, {
    locale?: "en";
}, {}>;
