export { bank_locking_unavailable as "bank.locking_unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Locking_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "This browser cannot coordinate bank operations across tabs. Use a browser that supports Web Locks." |
*
* @param {Bank_Locking_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_locking_unavailable: ((inputs?: Bank_Locking_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Locking_UnavailableInputs, {
    locale?: "en";
}, {}>;
