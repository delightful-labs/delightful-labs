export { status_saved_subject as "status.saved_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Saved_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} saved." |
*
* @param {Status_Saved_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_saved_subject: ((inputs: Status_Saved_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Saved_SubjectInputs, {
    locale?: "en";
}, {}>;
