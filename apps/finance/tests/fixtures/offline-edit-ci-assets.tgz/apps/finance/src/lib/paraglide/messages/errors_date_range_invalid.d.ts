export { errors_date_range_invalid as "errors.date_range_invalid" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Date_Range_InvalidInputs = {};
/**
* | output |
* | --- |
* | "Enter a start date and an end date on or after the start date." |
*
* @param {Errors_Date_Range_InvalidInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_date_range_invalid: ((inputs?: Errors_Date_Range_InvalidInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Date_Range_InvalidInputs, {
    locale?: "en";
}, {}>;
