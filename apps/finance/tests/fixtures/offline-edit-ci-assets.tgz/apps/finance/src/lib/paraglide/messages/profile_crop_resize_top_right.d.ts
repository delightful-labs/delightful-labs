export { profile_crop_resize_top_right as "profile.crop_resize_top_right" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_Resize_Top_RightInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from top right corner" |
*
* @param {Profile_Crop_Resize_Top_RightInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_resize_top_right: ((inputs?: Profile_Crop_Resize_Top_RightInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_Resize_Top_RightInputs, {
    locale?: "en";
}, {}>;
