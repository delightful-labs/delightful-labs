export { labels_selected_subjects as "labels.selected_subjects" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Selected_SubjectsInputs = {
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Selected {subjects}" |
*
* @param {Labels_Selected_SubjectsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_selected_subjects: ((inputs: Labels_Selected_SubjectsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Selected_SubjectsInputs, {
    locale?: "en";
}, {}>;
