export { actions_omitted as "actions.omitted" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_OmittedInputs = {};
/**
* | output |
* | --- |
* | "Omitted" |
*
* @param {Actions_OmittedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_omitted: ((inputs?: Actions_OmittedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_OmittedInputs, {
    locale?: "en";
}, {}>;
