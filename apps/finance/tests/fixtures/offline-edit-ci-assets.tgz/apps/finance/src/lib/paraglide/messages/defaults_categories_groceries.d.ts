export { defaults_categories_groceries as "defaults.categories.groceries" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_GroceriesInputs = {};
/**
* | output |
* | --- |
* | "Groceries" |
*
* @param {Defaults_Categories_GroceriesInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_groceries: ((inputs?: Defaults_Categories_GroceriesInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_GroceriesInputs, {
    locale?: "en";
}, {}>;
