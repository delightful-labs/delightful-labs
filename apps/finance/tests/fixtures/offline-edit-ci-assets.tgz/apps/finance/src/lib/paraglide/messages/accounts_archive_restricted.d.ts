export { accounts_archive_restricted as "accounts.archive_restricted" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Archive_RestrictedInputs = {};
/**
* | output |
* | --- |
* | "You do not have permission to archive this account." |
*
* @param {Accounts_Archive_RestrictedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_archive_restricted: ((inputs?: Accounts_Archive_RestrictedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Archive_RestrictedInputs, {
    locale?: "en";
}, {}>;
