export { transactions_unavailable as "transactions.unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "This transaction is unavailable in the selected workspace." |
*
* @param {Transactions_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_unavailable: ((inputs?: Transactions_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_UnavailableInputs, {
    locale?: "en";
}, {}>;
