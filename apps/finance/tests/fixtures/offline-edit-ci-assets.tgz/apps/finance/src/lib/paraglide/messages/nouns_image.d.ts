export { nouns_image as "nouns.image" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_ImageInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Image" |
* | * | "Images" |
*
* @param {Nouns_ImageInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_image: ((inputs: Nouns_ImageInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_ImageInputs, {
    locale?: "en";
}, {}>;
