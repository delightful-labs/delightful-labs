export { nouns_expense as "nouns.expense" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_ExpenseInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Expense" |
* | * | "Expenses" |
*
* @param {Nouns_ExpenseInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_expense: ((inputs: Nouns_ExpenseInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_ExpenseInputs, {
    locale?: "en";
}, {}>;
