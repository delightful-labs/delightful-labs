export { workspace_create_failed as "workspace.create_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Create_FailedInputs = {};
/**
* | output |
* | --- |
* | "Workspace creation could not finish. Check local storage and retry the same attempt." |
*
* @param {Workspace_Create_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_create_failed: ((inputs?: Workspace_Create_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Create_FailedInputs, {
    locale?: "en";
}, {}>;
