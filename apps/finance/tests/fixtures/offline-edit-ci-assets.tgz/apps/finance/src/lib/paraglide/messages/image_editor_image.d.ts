export { image_editor_image as "image_editor.image" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_ImageInputs = {};
/**
* | output |
* | --- |
* | "Image" |
*
* @param {Image_Editor_ImageInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_image: ((inputs?: Image_Editor_ImageInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_ImageInputs, {
    locale?: "en";
}, {}>;
