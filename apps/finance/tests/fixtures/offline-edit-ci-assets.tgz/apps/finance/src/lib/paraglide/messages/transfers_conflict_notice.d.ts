export { transfers_conflict_notice as "transfers.conflict_notice" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Conflict_NoticeInputs = {};
/**
* | output |
* | --- |
* | "This transfer link is inconsistent. Related transactions are excluded from totals until it is repaired." |
*
* @param {Transfers_Conflict_NoticeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_conflict_notice: ((inputs?: Transfers_Conflict_NoticeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Conflict_NoticeInputs, {
    locale?: "en";
}, {}>;
