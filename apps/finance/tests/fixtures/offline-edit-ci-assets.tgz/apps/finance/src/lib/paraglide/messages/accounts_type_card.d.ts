export { accounts_type_card as "accounts.type.card" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Type_CardInputs = {};
/**
* | output |
* | --- |
* | "Card" |
*
* @param {Accounts_Type_CardInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_type_card: ((inputs?: Accounts_Type_CardInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Type_CardInputs, {
    locale?: "en";
}, {}>;
