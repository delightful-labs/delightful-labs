export { bank_setup_creating_body as "bank.setup_creating_body" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Creating_BodyInputs = {};
/**
* | output |
* | --- |
* | "Choose your password manager and approve passkey creation. This passkey will protect your SimpleFIN connection. Your setup token has not been claimed." |
*
* @param {Bank_Setup_Creating_BodyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_creating_body: ((inputs?: Bank_Setup_Creating_BodyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Creating_BodyInputs, {
    locale?: "en";
}, {}>;
