export { images_crop_avatar_title as "images.crop_avatar_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Crop_Avatar_TitleInputs = {};
/**
* | output |
* | --- |
* | "Crop your avatar" |
*
* @param {Images_Crop_Avatar_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_crop_avatar_title: ((inputs?: Images_Crop_Avatar_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Crop_Avatar_TitleInputs, {
    locale?: "en";
}, {}>;
