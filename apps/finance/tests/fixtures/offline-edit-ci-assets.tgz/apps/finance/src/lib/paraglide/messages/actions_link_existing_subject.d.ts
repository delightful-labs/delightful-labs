export { actions_link_existing_subject as "actions.link_existing_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Link_Existing_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Link to existing {subject}" |
*
* @param {Actions_Link_Existing_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_link_existing_subject: ((inputs: Actions_Link_Existing_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Link_Existing_SubjectInputs, {
    locale?: "en";
}, {}>;
