export { workspace_empty as "workspace.empty" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_EmptyInputs = {};
/**
* | output |
* | --- |
* | "No accessible workspaces. Create a workspace to continue." |
*
* @param {Workspace_EmptyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_empty: ((inputs?: Workspace_EmptyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_EmptyInputs, {
    locale?: "en";
}, {}>;
