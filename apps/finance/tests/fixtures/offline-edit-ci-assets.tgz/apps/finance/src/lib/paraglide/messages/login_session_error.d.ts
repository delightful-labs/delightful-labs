export { login_session_error as "login.session_error" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Login_Session_ErrorInputs = {};
/**
* | output |
* | --- |
* | "The account could not be restored. Please try again." |
*
* @param {Login_Session_ErrorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const login_session_error: ((inputs?: Login_Session_ErrorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Login_Session_ErrorInputs, {
    locale?: "en";
}, {}>;
