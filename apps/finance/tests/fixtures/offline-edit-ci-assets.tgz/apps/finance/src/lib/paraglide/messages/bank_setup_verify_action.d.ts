export { bank_setup_verify_action as "bank.setup_verify_action" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Verify_ActionInputs = {};
/**
* | output |
* | --- |
* | "Test unlocking with my passkey" |
*
* @param {Bank_Setup_Verify_ActionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_verify_action: ((inputs?: Bank_Setup_Verify_ActionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Verify_ActionInputs, {
    locale?: "en";
}, {}>;
