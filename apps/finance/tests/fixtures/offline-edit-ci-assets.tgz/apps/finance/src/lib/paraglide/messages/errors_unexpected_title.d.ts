export { errors_unexpected_title as "errors.unexpected_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Unexpected_TitleInputs = {};
/**
* | output |
* | --- |
* | "Something went wrong" |
*
* @param {Errors_Unexpected_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_unexpected_title: ((inputs?: Errors_Unexpected_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Unexpected_TitleInputs, {
    locale?: "en";
}, {}>;
