export { permissions_update_failed as "permissions.update_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Permissions_Update_FailedInputs = {};
/**
* | output |
* | --- |
* | "Permissions could not be updated. Please try again." |
*
* @param {Permissions_Update_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const permissions_update_failed: ((inputs?: Permissions_Update_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Permissions_Update_FailedInputs, {
    locale?: "en";
}, {}>;
