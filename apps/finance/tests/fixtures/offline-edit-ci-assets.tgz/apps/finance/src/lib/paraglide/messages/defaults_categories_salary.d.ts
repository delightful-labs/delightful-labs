export { defaults_categories_salary as "defaults.categories.salary" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_SalaryInputs = {};
/**
* | output |
* | --- |
* | "Salary" |
*
* @param {Defaults_Categories_SalaryInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_salary: ((inputs?: Defaults_Categories_SalaryInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_SalaryInputs, {
    locale?: "en";
}, {}>;
