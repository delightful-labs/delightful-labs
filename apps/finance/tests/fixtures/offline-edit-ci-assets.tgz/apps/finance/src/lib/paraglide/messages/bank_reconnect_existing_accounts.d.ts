export { bank_reconnect_existing_accounts as "bank.reconnect_existing_accounts" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Reconnect_Existing_AccountsInputs = {};
/**
* | output |
* | --- |
* | "Reconnect existing accounts" |
*
* @param {Bank_Reconnect_Existing_AccountsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_reconnect_existing_accounts: ((inputs?: Bank_Reconnect_Existing_AccountsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Reconnect_Existing_AccountsInputs, {
    locale?: "en";
}, {}>;
