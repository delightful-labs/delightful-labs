export { actions_delete_subject as "actions.delete_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Delete_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Delete {subject}" |
*
* @param {Actions_Delete_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_delete_subject: ((inputs: Actions_Delete_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Delete_SubjectInputs, {
    locale?: "en";
}, {}>;
