export { bank_provider_failure as "bank.provider_failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Provider_FailureInputs = {};
/**
* | output |
* | --- |
* | "SimpleFIN could not complete the request. Check connectivity or reauthorize your accounts at SimpleFIN, then retry manually." |
*
* @param {Bank_Provider_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_provider_failure: ((inputs?: Bank_Provider_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Provider_FailureInputs, {
    locale?: "en";
}, {}>;
