export { bank_setup_save_action as "bank.setup_save_action" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Save_ActionInputs = {};
/**
* | output |
* | --- |
* | "Connect and save securely" |
*
* @param {Bank_Setup_Save_ActionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_save_action: ((inputs?: Bank_Setup_Save_ActionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Save_ActionInputs, {
    locale?: "en";
}, {}>;
