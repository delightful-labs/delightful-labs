export { labels_current_subject as "labels.current_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Current_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Current {subject}" |
*
* @param {Labels_Current_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_current_subject: ((inputs: Labels_Current_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Current_SubjectInputs, {
    locale?: "en";
}, {}>;
