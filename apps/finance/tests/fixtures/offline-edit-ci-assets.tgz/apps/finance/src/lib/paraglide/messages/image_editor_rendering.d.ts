export { image_editor_rendering as "image_editor.rendering" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_RenderingInputs = {};
/**
* | output |
* | --- |
* | "Rendering preview…" |
*
* @param {Image_Editor_RenderingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_rendering: ((inputs?: Image_Editor_RenderingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_RenderingInputs, {
    locale?: "en";
}, {}>;
