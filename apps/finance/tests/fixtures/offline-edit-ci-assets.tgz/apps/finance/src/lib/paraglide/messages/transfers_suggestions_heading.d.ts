export { transfers_suggestions_heading as "transfers.suggestions_heading" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Suggestions_HeadingInputs = {};
/**
* | output |
* | --- |
* | "Matching transactions" |
*
* @param {Transfers_Suggestions_HeadingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_suggestions_heading: ((inputs?: Transfers_Suggestions_HeadingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Suggestions_HeadingInputs, {
    locale?: "en";
}, {}>;
