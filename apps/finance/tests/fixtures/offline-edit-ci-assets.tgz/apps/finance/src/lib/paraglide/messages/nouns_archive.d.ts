export { nouns_archive as "nouns.archive" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_ArchiveInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Archive" |
* | * | "Archives" |
*
* @param {Nouns_ArchiveInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_archive: ((inputs: Nouns_ArchiveInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_ArchiveInputs, {
    locale?: "en";
}, {}>;
