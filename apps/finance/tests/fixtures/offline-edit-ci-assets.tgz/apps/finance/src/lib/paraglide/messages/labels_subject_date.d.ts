export { labels_subject_date as "labels.subject_date" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_DateInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} date" |
*
* @param {Labels_Subject_DateInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_date: ((inputs: Labels_Subject_DateInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_DateInputs, {
    locale?: "en";
}, {}>;
