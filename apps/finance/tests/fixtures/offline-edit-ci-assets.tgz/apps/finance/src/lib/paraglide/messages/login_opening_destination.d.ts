export { login_opening_destination as "login.opening_destination" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Login_Opening_DestinationInputs = {};
/**
* | output |
* | --- |
* | "Opening your account…" |
*
* @param {Login_Opening_DestinationInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const login_opening_destination: ((inputs?: Login_Opening_DestinationInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Login_Opening_DestinationInputs, {
    locale?: "en";
}, {}>;
