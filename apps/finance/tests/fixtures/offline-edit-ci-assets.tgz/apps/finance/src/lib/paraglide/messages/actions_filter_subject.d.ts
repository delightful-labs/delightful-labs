export { actions_filter_subject as "actions.filter_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Filter_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Filter {subject}" |
*
* @param {Actions_Filter_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_filter_subject: ((inputs: Actions_Filter_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Filter_SubjectInputs, {
    locale?: "en";
}, {}>;
