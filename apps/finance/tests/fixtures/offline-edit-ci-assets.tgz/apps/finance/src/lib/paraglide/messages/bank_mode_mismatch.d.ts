export { bank_mode_mismatch as "bank.mode_mismatch" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Mode_MismatchInputs = {};
/**
* | output |
* | --- |
* | "This workspace has a bank connection from the other mode. Select a dedicated workspace for this mode, or restart the app with the matching demo setting. The ..." |
*
* @param {Bank_Mode_MismatchInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_mode_mismatch: ((inputs?: Bank_Mode_MismatchInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Mode_MismatchInputs, {
    locale?: "en";
}, {}>;
