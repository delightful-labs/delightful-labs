export { bank_setup_saving_title as "bank.setup_saving_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Saving_TitleInputs = {};
/**
* | output |
* | --- |
* | "Saving your connection" |
*
* @param {Bank_Setup_Saving_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_saving_title: ((inputs?: Bank_Setup_Saving_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Saving_TitleInputs, {
    locale?: "en";
}, {}>;
