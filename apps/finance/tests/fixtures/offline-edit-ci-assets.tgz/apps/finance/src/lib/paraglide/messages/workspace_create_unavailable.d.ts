export { workspace_create_unavailable as "workspace.create_unavailable" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Create_UnavailableInputs = {};
/**
* | output |
* | --- |
* | "Workspace creation needs a ready login profile." |
*
* @param {Workspace_Create_UnavailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_create_unavailable: ((inputs?: Workspace_Create_UnavailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Create_UnavailableInputs, {
    locale?: "en";
}, {}>;
