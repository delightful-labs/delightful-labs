export { bank_result_time_outcome_imported_existing_omitted as "bank.result_time_outcome_imported_existing_omitted" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Result_Time_Outcome_Imported_Existing_OmittedInputs = {
    time: NonNullable<unknown>;
    outcome: NonNullable<unknown>;
    imported: NonNullable<unknown>;
    existing: NonNullable<unknown>;
    omitted: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Last sync: {time}. Outcome: {outcome}. Imported: {imported}; already present: {existing}; omitted: {omitted}." |
*
* @param {Bank_Result_Time_Outcome_Imported_Existing_OmittedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_result_time_outcome_imported_existing_omitted: ((inputs: Bank_Result_Time_Outcome_Imported_Existing_OmittedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Result_Time_Outcome_Imported_Existing_OmittedInputs, {
    locale?: "en";
}, {}>;
