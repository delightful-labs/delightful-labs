export { accounts_type_bank as "accounts.type.bank" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Type_BankInputs = {};
/**
* | output |
* | --- |
* | "Bank" |
*
* @param {Accounts_Type_BankInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_type_bank: ((inputs?: Accounts_Type_BankInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Type_BankInputs, {
    locale?: "en";
}, {}>;
