export { nouns_backup as "nouns.backup" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_BackupInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Backup" |
* | * | "Backups" |
*
* @param {Nouns_BackupInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_backup: ((inputs: Nouns_BackupInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_BackupInputs, {
    locale?: "en";
}, {}>;
