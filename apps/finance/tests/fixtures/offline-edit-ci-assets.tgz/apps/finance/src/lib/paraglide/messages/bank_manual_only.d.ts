export { bank_manual_only as "bank.manual_only" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Manual_OnlyInputs = {};
/**
* | output |
* | --- |
* | "Transactions are fetched only when you press Sync now. Each provider operation requires passkey verification." |
*
* @param {Bank_Manual_OnlyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_manual_only: ((inputs?: Bank_Manual_OnlyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Manual_OnlyInputs, {
    locale?: "en";
}, {}>;
