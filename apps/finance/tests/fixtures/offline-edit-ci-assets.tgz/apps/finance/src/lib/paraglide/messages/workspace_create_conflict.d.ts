export { workspace_create_conflict as "workspace.create_conflict" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Create_ConflictInputs = {};
/**
* | output |
* | --- |
* | "This creation attempt conflicts with existing records. Retry to reconcile without overwriting data." |
*
* @param {Workspace_Create_ConflictInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_create_conflict: ((inputs?: Workspace_Create_ConflictInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Create_ConflictInputs, {
    locale?: "en";
}, {}>;
