export { images_max_count as "images.max_count" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Max_CountInputs = {};
/**
* | output |
* | --- |
* | "Up to five images per transaction." |
*
* @param {Images_Max_CountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_max_count: ((inputs?: Images_Max_CountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Max_CountInputs, {
    locale?: "en";
}, {}>;
