export { image_editor_instructions as "image_editor.instructions" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_InstructionsInputs = {};
/**
* | output |
* | --- |
* | "Move the crop area or its corners to choose what to keep. Use arrow keys to move a focused handle; hold Shift for larger steps." |
*
* @param {Image_Editor_InstructionsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_instructions: ((inputs?: Image_Editor_InstructionsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_InstructionsInputs, {
    locale?: "en";
}, {}>;
