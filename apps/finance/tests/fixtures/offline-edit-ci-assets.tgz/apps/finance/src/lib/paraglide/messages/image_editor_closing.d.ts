export { image_editor_closing as "image_editor.closing" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_ClosingInputs = {};
/**
* | output |
* | --- |
* | "Closing image editor…" |
*
* @param {Image_Editor_ClosingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_closing: ((inputs?: Image_Editor_ClosingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_ClosingInputs, {
    locale?: "en";
}, {}>;
