export { nouns_passkey as "nouns.passkey" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_PasskeyInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Passkey" |
* | * | "Passkeys" |
*
* @param {Nouns_PasskeyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_passkey: ((inputs: Nouns_PasskeyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_PasskeyInputs, {
    locale?: "en";
}, {}>;
