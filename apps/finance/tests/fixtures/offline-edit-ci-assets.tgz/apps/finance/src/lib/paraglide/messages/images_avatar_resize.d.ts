export { images_avatar_resize as "images.avatar_resize" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Avatar_ResizeInputs = {};
/**
* | output |
* | --- |
* | "Images are resized for your avatar." |
*
* @param {Images_Avatar_ResizeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_avatar_resize: ((inputs?: Images_Avatar_ResizeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Avatar_ResizeInputs, {
    locale?: "en";
}, {}>;
