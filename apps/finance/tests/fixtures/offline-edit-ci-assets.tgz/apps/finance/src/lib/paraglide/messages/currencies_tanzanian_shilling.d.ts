export { currencies_tanzanian_shilling as "currencies.tanzanian_shilling" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Currencies_Tanzanian_ShillingInputs = {};
/**
* | output |
* | --- |
* | "Tanzanian shilling" |
*
* @param {Currencies_Tanzanian_ShillingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const currencies_tanzanian_shilling: ((inputs?: Currencies_Tanzanian_ShillingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Currencies_Tanzanian_ShillingInputs, {
    locale?: "en";
}, {}>;
