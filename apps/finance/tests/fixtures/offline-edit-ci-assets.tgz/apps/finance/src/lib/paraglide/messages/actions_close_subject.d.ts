export { actions_close_subject as "actions.close_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Close_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Close {subject}" |
*
* @param {Actions_Close_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_close_subject: ((inputs: Actions_Close_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Close_SubjectInputs, {
    locale?: "en";
}, {}>;
