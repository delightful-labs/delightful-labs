export { nouns_order as "nouns.order" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_OrderInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Order" |
* | * | "Orders" |
*
* @param {Nouns_OrderInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_order: ((inputs: Nouns_OrderInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_OrderInputs, {
    locale?: "en";
}, {}>;
