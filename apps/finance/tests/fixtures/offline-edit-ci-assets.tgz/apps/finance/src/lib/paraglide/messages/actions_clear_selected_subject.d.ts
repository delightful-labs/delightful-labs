export { actions_clear_selected_subject as "actions.clear_selected_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Clear_Selected_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Clear selected {subject}" |
*
* @param {Actions_Clear_Selected_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_clear_selected_subject: ((inputs: Actions_Clear_Selected_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Clear_Selected_SubjectInputs, {
    locale?: "en";
}, {}>;
