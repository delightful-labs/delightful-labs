export { actions_archive_subject as "actions.archive_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Archive_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Archive {subject}" |
*
* @param {Actions_Archive_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_archive_subject: ((inputs: Actions_Archive_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Archive_SubjectInputs, {
    locale?: "en";
}, {}>;
