export { image_editor_resize_bottom_right as "image_editor.resize_bottom_right" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Resize_Bottom_RightInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from bottom right corner" |
*
* @param {Image_Editor_Resize_Bottom_RightInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_resize_bottom_right: ((inputs?: Image_Editor_Resize_Bottom_RightInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Resize_Bottom_RightInputs, {
    locale?: "en";
}, {}>;
