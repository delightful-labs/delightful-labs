export { bank_setup_encrypt_title as "bank.setup_encrypt_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Encrypt_TitleInputs = {};
/**
* | output |
* | --- |
* | "Step 3: Test encryption" |
*
* @param {Bank_Setup_Encrypt_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_encrypt_title: ((inputs?: Bank_Setup_Encrypt_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Encrypt_TitleInputs, {
    locale?: "en";
}, {}>;
