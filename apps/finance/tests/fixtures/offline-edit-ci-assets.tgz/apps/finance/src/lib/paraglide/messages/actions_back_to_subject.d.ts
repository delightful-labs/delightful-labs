export { actions_back_to_subject as "actions.back_to_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Back_To_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Back to {subject}" |
*
* @param {Actions_Back_To_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_back_to_subject: ((inputs: Actions_Back_To_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Back_To_SubjectInputs, {
    locale?: "en";
}, {}>;
