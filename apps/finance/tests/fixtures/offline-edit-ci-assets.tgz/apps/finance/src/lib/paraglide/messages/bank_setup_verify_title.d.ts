export { bank_setup_verify_title as "bank.setup_verify_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Verify_TitleInputs = {};
/**
* | output |
* | --- |
* | "Step 4: Test unlocking" |
*
* @param {Bank_Setup_Verify_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_verify_title: ((inputs?: Bank_Setup_Verify_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Verify_TitleInputs, {
    locale?: "en";
}, {}>;
