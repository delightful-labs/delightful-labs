export { tags_kind_unassigned as "tags.kind_unassigned" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Tags_Kind_UnassignedInputs = {};
/**
* | output |
* | --- |
* | "Type unassigned; unavailable for new transactions until migration." |
*
* @param {Tags_Kind_UnassignedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const tags_kind_unassigned: ((inputs?: Tags_Kind_UnassignedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Tags_Kind_UnassignedInputs, {
    locale?: "en";
}, {}>;
