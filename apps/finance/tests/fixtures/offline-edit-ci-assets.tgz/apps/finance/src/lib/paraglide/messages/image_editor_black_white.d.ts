export { image_editor_black_white as "image_editor.black_white" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Black_WhiteInputs = {};
/**
* | output |
* | --- |
* | "Black and white" |
*
* @param {Image_Editor_Black_WhiteInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_black_white: ((inputs?: Image_Editor_Black_WhiteInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Black_WhiteInputs, {
    locale?: "en";
}, {}>;
