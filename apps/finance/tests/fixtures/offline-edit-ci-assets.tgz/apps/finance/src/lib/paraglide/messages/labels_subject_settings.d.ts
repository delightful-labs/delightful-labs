export { labels_subject_settings as "labels.subject_settings" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_SettingsInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} settings" |
*
* @param {Labels_Subject_SettingsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_settings: ((inputs: Labels_Subject_SettingsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_SettingsInputs, {
    locale?: "en";
}, {}>;
