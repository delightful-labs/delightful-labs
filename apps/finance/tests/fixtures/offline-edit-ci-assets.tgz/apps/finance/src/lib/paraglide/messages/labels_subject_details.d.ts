export { labels_subject_details as "labels.subject_details" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_DetailsInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} details" |
*
* @param {Labels_Subject_DetailsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_details: ((inputs: Labels_Subject_DetailsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_DetailsInputs, {
    locale?: "en";
}, {}>;
