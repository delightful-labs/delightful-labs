export { forms_unknown as "forms.unknown" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_UnknownInputs = {};
/**
* | output |
* | --- |
* | "The save result is unknown. Check your records before trying again." |
*
* @param {Forms_UnknownInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_unknown: ((inputs?: Forms_UnknownInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_UnknownInputs, {
    locale?: "en";
}, {}>;
