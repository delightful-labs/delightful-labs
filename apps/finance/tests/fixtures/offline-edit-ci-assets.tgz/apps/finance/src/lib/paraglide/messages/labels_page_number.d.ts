export { labels_page_number as "labels.page_number" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Page_NumberInputs = {
    number: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Page {number}" |
*
* @param {Labels_Page_NumberInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_page_number: ((inputs: Labels_Page_NumberInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Page_NumberInputs, {
    locale?: "en";
}, {}>;
