export { forms_unavailable_reference as "forms.unavailable_reference" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Unavailable_ReferenceInputs = {};
/**
* | output |
* | --- |
* | "A selected record is no longer available in this workspace. Select an available record and try again." |
*
* @param {Forms_Unavailable_ReferenceInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_unavailable_reference: ((inputs?: Forms_Unavailable_ReferenceInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Unavailable_ReferenceInputs, {
    locale?: "en";
}, {}>;
