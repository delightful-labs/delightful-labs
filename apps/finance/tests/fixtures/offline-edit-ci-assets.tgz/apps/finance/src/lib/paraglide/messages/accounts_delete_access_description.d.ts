export { accounts_delete_access_description as "accounts.delete_access_description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Delete_Access_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "Delete access is granted separately from account write access." |
*
* @param {Accounts_Delete_Access_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_delete_access_description: ((inputs?: Accounts_Delete_Access_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Delete_Access_DescriptionInputs, {
    locale?: "en";
}, {}>;
