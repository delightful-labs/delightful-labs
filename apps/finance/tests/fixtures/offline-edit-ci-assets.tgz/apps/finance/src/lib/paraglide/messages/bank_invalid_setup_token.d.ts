export { bank_invalid_setup_token as "bank.invalid_setup_token" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Invalid_Setup_TokenInputs = {};
/**
* | output |
* | --- |
* | "This setup token is invalid or uses an unsupported SimpleFIN address. Paste the complete setup token from SimpleFIN Bridge. No provider request was made and ..." |
*
* @param {Bank_Invalid_Setup_TokenInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_invalid_setup_token: ((inputs?: Bank_Invalid_Setup_TokenInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Invalid_Setup_TokenInputs, {
    locale?: "en";
}, {}>;
