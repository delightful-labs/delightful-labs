export { bank_idle_step as "bank.idle_step" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Idle_StepInputs = {
    step: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{step} to begin." |
*
* @param {Bank_Idle_StepInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_idle_step: ((inputs: Bank_Idle_StepInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Idle_StepInputs, {
    locale?: "en";
}, {}>;
