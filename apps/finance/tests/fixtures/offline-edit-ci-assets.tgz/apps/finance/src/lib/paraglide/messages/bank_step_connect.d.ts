export { bank_step_connect as "bank.step_connect" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Step_ConnectInputs = {};
/**
* | output |
* | --- |
* | "Connect" |
*
* @param {Bank_Step_ConnectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_step_connect: ((inputs?: Bank_Step_ConnectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Step_ConnectInputs, {
    locale?: "en";
}, {}>;
