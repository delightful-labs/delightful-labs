export { errors_not_found_title as "errors.not_found_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Not_Found_TitleInputs = {};
/**
* | output |
* | --- |
* | "Page not found" |
*
* @param {Errors_Not_Found_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_not_found_title: ((inputs?: Errors_Not_Found_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Not_Found_TitleInputs, {
    locale?: "en";
}, {}>;
