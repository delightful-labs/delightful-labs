export { workspace_loading as "workspace.loading" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_LoadingInputs = {};
/**
* | output |
* | --- |
* | "Getting your workspaces ready…" |
*
* @param {Workspace_LoadingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_loading: ((inputs?: Workspace_LoadingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_LoadingInputs, {
    locale?: "en";
}, {}>;
