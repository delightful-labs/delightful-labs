export { transactions_pagination_label as "transactions.pagination.label" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Pagination_LabelInputs = {};
/**
* | output |
* | --- |
* | "Transaction pages" |
*
* @param {Transactions_Pagination_LabelInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_pagination_label: ((inputs?: Transactions_Pagination_LabelInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Pagination_LabelInputs, {
    locale?: "en";
}, {}>;
