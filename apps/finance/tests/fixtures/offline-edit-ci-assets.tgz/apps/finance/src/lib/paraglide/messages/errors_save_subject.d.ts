export { errors_save_subject as "errors.save_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Save_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Could not save {subject}." |
*
* @param {Errors_Save_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_save_subject: ((inputs: Errors_Save_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Save_SubjectInputs, {
    locale?: "en";
}, {}>;
