export { pwa_update_available as "pwa_update.available" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Pwa_Update_AvailableInputs = {};
/**
* | output |
* | --- |
* | "A new version is available." |
*
* @param {Pwa_Update_AvailableInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const pwa_update_available: ((inputs?: Pwa_Update_AvailableInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Pwa_Update_AvailableInputs, {
    locale?: "en";
}, {}>;
