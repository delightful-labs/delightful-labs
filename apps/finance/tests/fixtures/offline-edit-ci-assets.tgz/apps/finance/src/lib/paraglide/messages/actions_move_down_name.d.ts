export { actions_move_down_name as "actions.move_down_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Move_Down_NameInputs = {
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Move {name} down" |
*
* @param {Actions_Move_Down_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_move_down_name: ((inputs: Actions_Move_Down_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Move_Down_NameInputs, {
    locale?: "en";
}, {}>;
