export { transfers_convert_to_transfer as "transfers.convert_to_transfer" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Convert_To_TransferInputs = {};
/**
* | output |
* | --- |
* | "Convert this transaction to a transfer" |
*
* @param {Transfers_Convert_To_TransferInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_convert_to_transfer: ((inputs?: Transfers_Convert_To_TransferInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Convert_To_TransferInputs, {
    locale?: "en";
}, {}>;
