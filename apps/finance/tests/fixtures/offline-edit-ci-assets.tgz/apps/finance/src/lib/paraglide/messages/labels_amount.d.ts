export { labels_amount as "labels.amount" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_AmountInputs = {};
/**
* | output |
* | --- |
* | "Amount" |
*
* @param {Labels_AmountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_amount: ((inputs?: Labels_AmountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_AmountInputs, {
    locale?: "en";
}, {}>;
