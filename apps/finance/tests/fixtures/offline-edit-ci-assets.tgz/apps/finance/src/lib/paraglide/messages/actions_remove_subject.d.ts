export { actions_remove_subject as "actions.remove_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Remove_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Remove {subject}" |
*
* @param {Actions_Remove_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_remove_subject: ((inputs: Actions_Remove_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Remove_SubjectInputs, {
    locale?: "en";
}, {}>;
