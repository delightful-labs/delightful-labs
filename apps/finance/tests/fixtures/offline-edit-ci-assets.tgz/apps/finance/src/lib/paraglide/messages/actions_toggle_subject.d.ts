export { actions_toggle_subject as "actions.toggle_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Toggle_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Toggle {subject}" |
*
* @param {Actions_Toggle_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_toggle_subject: ((inputs: Actions_Toggle_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Toggle_SubjectInputs, {
    locale?: "en";
}, {}>;
