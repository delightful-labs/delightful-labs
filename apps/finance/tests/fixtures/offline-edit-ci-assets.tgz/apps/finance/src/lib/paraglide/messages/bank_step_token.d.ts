export { bank_step_token as "bank.step_token" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Step_TokenInputs = {};
/**
* | output |
* | --- |
* | "Enter setup token" |
*
* @param {Bank_Step_TokenInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_step_token: ((inputs?: Bank_Step_TokenInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Step_TokenInputs, {
    locale?: "en";
}, {}>;
