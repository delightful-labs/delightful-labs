export { images_max_file_size as "images.max_file_size" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Max_File_SizeInputs = {};
/**
* | output |
* | --- |
* | "Up to 10 MiB per image." |
*
* @param {Images_Max_File_SizeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_max_file_size: ((inputs?: Images_Max_File_SizeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Max_File_SizeInputs, {
    locale?: "en";
}, {}>;
