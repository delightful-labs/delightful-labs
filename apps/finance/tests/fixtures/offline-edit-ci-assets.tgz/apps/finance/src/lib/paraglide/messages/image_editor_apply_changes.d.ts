export { image_editor_apply_changes as "image_editor.apply_changes" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Apply_ChangesInputs = {};
/**
* | output |
* | --- |
* | "Apply changes" |
*
* @param {Image_Editor_Apply_ChangesInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_apply_changes: ((inputs?: Image_Editor_Apply_ChangesInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Apply_ChangesInputs, {
    locale?: "en";
}, {}>;
