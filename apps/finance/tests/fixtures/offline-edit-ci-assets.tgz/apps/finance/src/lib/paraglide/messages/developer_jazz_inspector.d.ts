export { developer_jazz_inspector as "developer.jazz_inspector" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_Jazz_InspectorInputs = {};
/**
* | output |
* | --- |
* | "Jazz inspector" |
*
* @param {Developer_Jazz_InspectorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_jazz_inspector: ((inputs?: Developer_Jazz_InspectorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_Jazz_InspectorInputs, {
    locale?: "en";
}, {}>;
