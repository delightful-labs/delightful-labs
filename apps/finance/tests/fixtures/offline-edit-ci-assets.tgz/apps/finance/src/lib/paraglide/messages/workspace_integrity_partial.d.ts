export { workspace_integrity_partial as "workspace.integrity_partial" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Integrity_PartialInputs = {};
/**
* | output |
* | --- |
* | "Some required workspace records need repair. An administrator may be needed to repair profile attribution." |
*
* @param {Workspace_Integrity_PartialInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_integrity_partial: ((inputs?: Workspace_Integrity_PartialInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Integrity_PartialInputs, {
    locale?: "en";
}, {}>;
