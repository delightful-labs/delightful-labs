export { database_online as "database.online" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Database_OnlineInputs = {};
/**
* | output |
* | --- |
* | "Online" |
*
* @param {Database_OnlineInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const database_online: ((inputs?: Database_OnlineInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Database_OnlineInputs, {
    locale?: "en";
}, {}>;
