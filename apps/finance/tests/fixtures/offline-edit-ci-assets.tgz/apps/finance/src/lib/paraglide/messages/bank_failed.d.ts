export { bank_failed as "bank.failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_FailedInputs = {};
/**
* | output |
* | --- |
* | "Failed" |
*
* @param {Bank_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_failed: ((inputs?: Bank_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_FailedInputs, {
    locale?: "en";
}, {}>;
