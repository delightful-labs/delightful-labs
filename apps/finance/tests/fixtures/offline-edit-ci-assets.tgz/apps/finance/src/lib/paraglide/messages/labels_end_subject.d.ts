export { labels_end_subject as "labels.end_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_End_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "End {subject}" |
*
* @param {Labels_End_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_end_subject: ((inputs: Labels_End_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_End_SubjectInputs, {
    locale?: "en";
}, {}>;
