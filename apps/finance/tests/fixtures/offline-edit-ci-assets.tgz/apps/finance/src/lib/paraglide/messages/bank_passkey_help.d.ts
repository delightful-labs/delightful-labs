export { bank_passkey_help as "bank.passkey_help" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Passkey_HelpInputs = {};
/**
* | output |
* | --- |
* | "First create a passkey. We will then explain two separate tests: encrypting a harmless sample and unlocking it again. Your SimpleFIN token is claimed only af..." |
*
* @param {Bank_Passkey_HelpInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_passkey_help: ((inputs?: Bank_Passkey_HelpInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Passkey_HelpInputs, {
    locale?: "en";
}, {}>;
