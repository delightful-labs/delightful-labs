export { transactions_empty_title as "transactions.empty.title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Empty_TitleInputs = {};
/**
* | output |
* | --- |
* | "Your recent activity will appear here." |
*
* @param {Transactions_Empty_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_empty_title: ((inputs?: Transactions_Empty_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Empty_TitleInputs, {
    locale?: "en";
}, {}>;
