export { errors_data_changed as "errors.data_changed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Data_ChangedInputs = {};
/**
* | output |
* | --- |
* | "The data changed. Please try again." |
*
* @param {Errors_Data_ChangedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_data_changed: ((inputs?: Errors_Data_ChangedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Data_ChangedInputs, {
    locale?: "en";
}, {}>;
