export { bank_recovery as "bank.recovery" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_RecoveryInputs = {};
/**
* | output |
* | --- |
* | "Reconnect with a new setup token and passkey. Imported data and mappings remain. Disconnect also requires revoking access at SimpleFIN to invalidate previous..." |
*
* @param {Bank_RecoveryInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_recovery: ((inputs?: Bank_RecoveryInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_RecoveryInputs, {
    locale?: "en";
}, {}>;
