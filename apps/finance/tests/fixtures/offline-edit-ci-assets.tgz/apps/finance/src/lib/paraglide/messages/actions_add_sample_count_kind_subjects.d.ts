export { actions_add_sample_count_kind_subjects as "actions.add_sample_count_kind_subjects" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Add_Sample_Count_Kind_SubjectsInputs = {
    count: NonNullable<unknown>;
    kind: NonNullable<unknown>;
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Add {count} sample {kind} {subjects}" |
*
* @param {Actions_Add_Sample_Count_Kind_SubjectsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_add_sample_count_kind_subjects: ((inputs: Actions_Add_Sample_Count_Kind_SubjectsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Add_Sample_Count_Kind_SubjectsInputs, {
    locale?: "en";
}, {}>;
