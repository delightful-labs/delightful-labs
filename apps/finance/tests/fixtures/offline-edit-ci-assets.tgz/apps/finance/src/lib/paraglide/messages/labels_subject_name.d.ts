export { labels_subject_name as "labels.subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Subject_NameInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} name" |
*
* @param {Labels_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_subject_name: ((inputs: Labels_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Subject_NameInputs, {
    locale?: "en";
}, {}>;
