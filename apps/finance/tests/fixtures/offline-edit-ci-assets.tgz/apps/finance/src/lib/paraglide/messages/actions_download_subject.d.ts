export { actions_download_subject as "actions.download_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Download_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Download {subject}" |
*
* @param {Actions_Download_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_download_subject: ((inputs: Actions_Download_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Download_SubjectInputs, {
    locale?: "en";
}, {}>;
