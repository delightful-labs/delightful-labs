export { nouns_check as "nouns.check" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_CheckInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Check" |
* | * | "Checks" |
*
* @param {Nouns_CheckInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_check: ((inputs: Nouns_CheckInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_CheckInputs, {
    locale?: "en";
}, {}>;
