export { actions_disconnect_subject as "actions.disconnect_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Disconnect_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Disconnect {subject}" |
*
* @param {Actions_Disconnect_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_disconnect_subject: ((inputs: Actions_Disconnect_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Disconnect_SubjectInputs, {
    locale?: "en";
}, {}>;
