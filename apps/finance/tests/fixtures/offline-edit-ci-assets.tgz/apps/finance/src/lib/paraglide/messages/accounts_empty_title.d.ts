export { accounts_empty_title as "accounts.empty.title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Accounts_Empty_TitleInputs = {};
/**
* | output |
* | --- |
* | "Start with one place you keep money." |
*
* @param {Accounts_Empty_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const accounts_empty_title: ((inputs?: Accounts_Empty_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Accounts_Empty_TitleInputs, {
    locale?: "en";
}, {}>;
