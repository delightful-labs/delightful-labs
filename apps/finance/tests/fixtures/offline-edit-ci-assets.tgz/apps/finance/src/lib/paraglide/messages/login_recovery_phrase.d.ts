export { login_recovery_phrase as "login.recovery_phrase" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Login_Recovery_PhraseInputs = {};
/**
* | output |
* | --- |
* | "Recovery phrase" |
*
* @param {Login_Recovery_PhraseInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const login_recovery_phrase: ((inputs?: Login_Recovery_PhraseInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Login_Recovery_PhraseInputs, {
    locale?: "en";
}, {}>;
