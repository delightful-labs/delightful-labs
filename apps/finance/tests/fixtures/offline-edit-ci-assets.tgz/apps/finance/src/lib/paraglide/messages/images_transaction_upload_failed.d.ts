export { images_transaction_upload_failed as "images.transaction_upload_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Transaction_Upload_FailedInputs = {};
/**
* | output |
* | --- |
* | "The transaction was saved, but some images could not be attached." |
*
* @param {Images_Transaction_Upload_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_transaction_upload_failed: ((inputs?: Images_Transaction_Upload_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Transaction_Upload_FailedInputs, {
    locale?: "en";
}, {}>;
