export { image_editor_preview as "image_editor.preview" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_PreviewInputs = {};
/**
* | output |
* | --- |
* | "Preview Image" |
*
* @param {Image_Editor_PreviewInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_preview: ((inputs?: Image_Editor_PreviewInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_PreviewInputs, {
    locale?: "en";
}, {}>;
