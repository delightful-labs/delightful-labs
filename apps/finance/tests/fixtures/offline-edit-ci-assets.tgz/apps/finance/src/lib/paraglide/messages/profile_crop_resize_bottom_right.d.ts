export { profile_crop_resize_bottom_right as "profile.crop_resize_bottom_right" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_Resize_Bottom_RightInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from bottom right corner" |
*
* @param {Profile_Crop_Resize_Bottom_RightInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_resize_bottom_right: ((inputs?: Profile_Crop_Resize_Bottom_RightInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_Resize_Bottom_RightInputs, {
    locale?: "en";
}, {}>;
