export { bank_step_completed as "bank.step_completed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Step_CompletedInputs = {};
/**
* | output |
* | --- |
* | "completed" |
*
* @param {Bank_Step_CompletedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_step_completed: ((inputs?: Bank_Step_CompletedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Step_CompletedInputs, {
    locale?: "en";
}, {}>;
