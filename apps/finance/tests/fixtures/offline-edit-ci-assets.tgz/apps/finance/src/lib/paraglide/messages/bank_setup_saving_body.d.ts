export { bank_setup_saving_body as "bank.setup_saving_body" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Saving_BodyInputs = {};
/**
* | output |
* | --- |
* | "Claiming your SimpleFIN token and saving the encrypted credential. The connection will be locked when setup finishes." |
*
* @param {Bank_Setup_Saving_BodyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_saving_body: ((inputs?: Bank_Setup_Saving_BodyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Saving_BodyInputs, {
    locale?: "en";
}, {}>;
