export { bank_succeeded as "bank.succeeded" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_SucceededInputs = {};
/**
* | output |
* | --- |
* | "Succeeded" |
*
* @param {Bank_SucceededInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_succeeded: ((inputs?: Bank_SucceededInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_SucceededInputs, {
    locale?: "en";
}, {}>;
