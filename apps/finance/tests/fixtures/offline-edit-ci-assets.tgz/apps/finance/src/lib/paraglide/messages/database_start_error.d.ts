export { database_start_error as "database.start_error" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Database_Start_ErrorInputs = {};
/**
* | output |
* | --- |
* | "Your finances could not be opened." |
*
* @param {Database_Start_ErrorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const database_start_error: ((inputs?: Database_Start_ErrorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Database_Start_ErrorInputs, {
    locale?: "en";
}, {}>;
