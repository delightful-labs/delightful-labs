export { forms_interrupted_saved as "forms.interrupted_saved" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Interrupted_SavedInputs = {};
/**
* | output |
* | --- |
* | "The change was saved locally before the request ended. Check the original record before trying again." |
*
* @param {Forms_Interrupted_SavedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_interrupted_saved: ((inputs?: Forms_Interrupted_SavedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Interrupted_SavedInputs, {
    locale?: "en";
}, {}>;
