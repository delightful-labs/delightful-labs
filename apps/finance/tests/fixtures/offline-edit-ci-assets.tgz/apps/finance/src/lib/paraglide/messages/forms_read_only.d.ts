export { forms_read_only as "forms.read_only" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Read_OnlyInputs = {};
/**
* | output |
* | --- |
* | "You do not have permission to make this change." |
*
* @param {Forms_Read_OnlyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_read_only: ((inputs?: Forms_Read_OnlyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Read_OnlyInputs, {
    locale?: "en";
}, {}>;
