export { images_preview_name as "images.preview_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Preview_NameInputs = {
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Preview of {name}" |
*
* @param {Images_Preview_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_preview_name: ((inputs: Images_Preview_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Preview_NameInputs, {
    locale?: "en";
}, {}>;
