export { profile_crop_resize_top_left as "profile.crop_resize_top_left" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Crop_Resize_Top_LeftInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from top left corner" |
*
* @param {Profile_Crop_Resize_Top_LeftInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_crop_resize_top_left: ((inputs?: Profile_Crop_Resize_Top_LeftInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Crop_Resize_Top_LeftInputs, {
    locale?: "en";
}, {}>;
