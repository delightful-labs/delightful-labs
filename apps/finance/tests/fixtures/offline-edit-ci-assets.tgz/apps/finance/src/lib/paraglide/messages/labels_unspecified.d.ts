export { labels_unspecified as "labels.unspecified" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_UnspecifiedInputs = {};
/**
* | output |
* | --- |
* | "Unspecified" |
*
* @param {Labels_UnspecifiedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_unspecified: ((inputs?: Labels_UnspecifiedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_UnspecifiedInputs, {
    locale?: "en";
}, {}>;
