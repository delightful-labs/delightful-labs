export { nouns_workspace as "nouns.workspace" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_WorkspaceInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Workspace" |
* | * | "Workspaces" |
*
* @param {Nouns_WorkspaceInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_workspace: ((inputs: Nouns_WorkspaceInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_WorkspaceInputs, {
    locale?: "en";
}, {}>;
