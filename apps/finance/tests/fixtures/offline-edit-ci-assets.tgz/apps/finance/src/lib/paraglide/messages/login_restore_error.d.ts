export { login_restore_error as "login.restore_error" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Login_Restore_ErrorInputs = {};
/**
* | output |
* | --- |
* | "The account could not be restored. Check the recovery phrase and try again." |
*
* @param {Login_Restore_ErrorInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const login_restore_error: ((inputs?: Login_Restore_ErrorInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Login_Restore_ErrorInputs, {
    locale?: "en";
}, {}>;
