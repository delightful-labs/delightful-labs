export { database_offline as "database.offline" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Database_OfflineInputs = {};
/**
* | output |
* | --- |
* | "Offline" |
*
* @param {Database_OfflineInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const database_offline: ((inputs?: Database_OfflineInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Database_OfflineInputs, {
    locale?: "en";
}, {}>;
