export { transactions_samples_description as "transactions.samples.description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Samples_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "Development tool: saves real sample transactions to the first selected writable account in this workspace." |
*
* @param {Transactions_Samples_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_samples_description: ((inputs?: Transactions_Samples_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Samples_DescriptionInputs, {
    locale?: "en";
}, {}>;
