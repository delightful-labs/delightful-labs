export { bank_setup_save_title as "bank.setup_save_title" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Save_TitleInputs = {};
/**
* | output |
* | --- |
* | "Step 5: Connect SimpleFIN" |
*
* @param {Bank_Setup_Save_TitleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_save_title: ((inputs?: Bank_Setup_Save_TitleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Save_TitleInputs, {
    locale?: "en";
}, {}>;
