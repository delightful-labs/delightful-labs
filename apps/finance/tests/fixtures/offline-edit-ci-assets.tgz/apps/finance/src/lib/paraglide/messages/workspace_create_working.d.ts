export { workspace_create_working as "workspace.create_working" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Create_WorkingInputs = {};
/**
* | output |
* | --- |
* | "Preparing your workspace…" |
*
* @param {Workspace_Create_WorkingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_create_working: ((inputs?: Workspace_Create_WorkingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Create_WorkingInputs, {
    locale?: "en";
}, {}>;
