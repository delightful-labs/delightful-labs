export { bank_other_tab as "bank.other_tab" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Other_TabInputs = {};
/**
* | output |
* | --- |
* | "A bank operation is already running in another tab. Wait for it to finish, then try again." |
*
* @param {Bank_Other_TabInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_other_tab: ((inputs?: Bank_Other_TabInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Other_TabInputs, {
    locale?: "en";
}, {}>;
