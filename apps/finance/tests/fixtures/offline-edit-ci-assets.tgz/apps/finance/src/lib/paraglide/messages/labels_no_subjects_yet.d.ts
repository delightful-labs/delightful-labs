export { labels_no_subjects_yet as "labels.no_subjects_yet" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_No_Subjects_YetInputs = {
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "No {subjects} yet." |
*
* @param {Labels_No_Subjects_YetInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_no_subjects_yet: ((inputs: Labels_No_Subjects_YetInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_No_Subjects_YetInputs, {
    locale?: "en";
}, {}>;
