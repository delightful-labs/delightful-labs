export { labels_all_subjects as "labels.all_subjects" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_All_SubjectsInputs = {
    subjects: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "All {subjects}" |
*
* @param {Labels_All_SubjectsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_all_subjects: ((inputs: Labels_All_SubjectsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_All_SubjectsInputs, {
    locale?: "en";
}, {}>;
