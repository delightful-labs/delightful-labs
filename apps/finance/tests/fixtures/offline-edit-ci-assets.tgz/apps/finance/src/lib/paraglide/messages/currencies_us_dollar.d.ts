export { currencies_us_dollar as "currencies.us_dollar" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Currencies_Us_DollarInputs = {};
/**
* | output |
* | --- |
* | "US dollar" |
*
* @param {Currencies_Us_DollarInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const currencies_us_dollar: ((inputs?: Currencies_Us_DollarInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Currencies_Us_DollarInputs, {
    locale?: "en";
}, {}>;
