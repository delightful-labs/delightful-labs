export { pwa_update_accept as "pwa_update.accept" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Pwa_Update_AcceptInputs = {};
/**
* | output |
* | --- |
* | "Update and reload" |
*
* @param {Pwa_Update_AcceptInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const pwa_update_accept: ((inputs?: Pwa_Update_AcceptInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Pwa_Update_AcceptInputs, {
    locale?: "en";
}, {}>;
