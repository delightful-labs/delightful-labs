export { forms_enter_subject as "forms.enter_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Enter_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Enter {subject}" |
*
* @param {Forms_Enter_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_enter_subject: ((inputs: Forms_Enter_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Enter_SubjectInputs, {
    locale?: "en";
}, {}>;
