export { actions_save as "actions.save" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_SaveInputs = {};
/**
* | output |
* | --- |
* | "Save" |
*
* @param {Actions_SaveInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_save: ((inputs?: Actions_SaveInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_SaveInputs, {
    locale?: "en";
}, {}>;
