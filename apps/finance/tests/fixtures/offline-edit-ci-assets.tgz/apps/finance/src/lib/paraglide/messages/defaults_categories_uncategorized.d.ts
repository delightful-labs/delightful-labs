export { defaults_categories_uncategorized as "defaults.categories.uncategorized" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_UncategorizedInputs = {};
/**
* | output |
* | --- |
* | "Uncategorized" |
*
* @param {Defaults_Categories_UncategorizedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_uncategorized: ((inputs?: Defaults_Categories_UncategorizedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_UncategorizedInputs, {
    locale?: "en";
}, {}>;
