export { image_editor_resize_bottom_left as "image_editor.resize_bottom_left" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Resize_Bottom_LeftInputs = {};
/**
* | output |
* | --- |
* | "Resize crop from bottom left corner" |
*
* @param {Image_Editor_Resize_Bottom_LeftInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_resize_bottom_left: ((inputs?: Image_Editor_Resize_Bottom_LeftInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Resize_Bottom_LeftInputs, {
    locale?: "en";
}, {}>;
