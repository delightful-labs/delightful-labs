export { app_short_name as "app.short_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type App_Short_NameInputs = {};
/**
* | output |
* | --- |
* | "Finance" |
*
* @param {App_Short_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const app_short_name: ((inputs?: App_Short_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<App_Short_NameInputs, {
    locale?: "en";
}, {}>;
