export { workspace_create_recovered as "workspace.create_recovered" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Workspace_Create_RecoveredInputs = {};
/**
* | output |
* | --- |
* | "An unfinished creation attempt was found. Retry uses the same workspace identity." |
*
* @param {Workspace_Create_RecoveredInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const workspace_create_recovered: ((inputs?: Workspace_Create_RecoveredInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Workspace_Create_RecoveredInputs, {
    locale?: "en";
}, {}>;
