export { status_archived_subject_name as "status.archived_subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Archived_Subject_NameInputs = {
    subject: NonNullable<unknown>;
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} {name} archived." |
*
* @param {Status_Archived_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_archived_subject_name: ((inputs: Status_Archived_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Archived_Subject_NameInputs, {
    locale?: "en";
}, {}>;
