export { bank_success as "bank.success" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_SuccessInputs = {};
/**
* | output |
* | --- |
* | "Operation completed. Credential locked." |
*
* @param {Bank_SuccessInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_success: ((inputs?: Bank_SuccessInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_SuccessInputs, {
    locale?: "en";
}, {}>;
