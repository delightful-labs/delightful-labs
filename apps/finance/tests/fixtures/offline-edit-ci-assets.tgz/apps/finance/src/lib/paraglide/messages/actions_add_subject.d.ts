export { actions_add_subject as "actions.add_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Add_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Add {subject}" |
*
* @param {Actions_Add_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_add_subject: ((inputs: Actions_Add_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Add_SubjectInputs, {
    locale?: "en";
}, {}>;
