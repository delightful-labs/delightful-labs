export { status_removed_subject_name as "status.removed_subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Removed_Subject_NameInputs = {
    subject: NonNullable<unknown>;
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} {name} removed." |
*
* @param {Status_Removed_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_removed_subject_name: ((inputs: Status_Removed_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Removed_Subject_NameInputs, {
    locale?: "en";
}, {}>;
