export { transactions_samples_saved_count as "transactions.samples.saved_count" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Samples_Saved_CountInputs = {
    count: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Saved {count} of 25 sample transactions." |
*
* @param {Transactions_Samples_Saved_CountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_samples_saved_count: ((inputs: Transactions_Samples_Saved_CountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Samples_Saved_CountInputs, {
    locale?: "en";
}, {}>;
