export { status_done as "status.done" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_DoneInputs = {};
/**
* | output |
* | --- |
* | "Done" |
*
* @param {Status_DoneInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_done: ((inputs?: Status_DoneInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_DoneInputs, {
    locale?: "en";
}, {}>;
