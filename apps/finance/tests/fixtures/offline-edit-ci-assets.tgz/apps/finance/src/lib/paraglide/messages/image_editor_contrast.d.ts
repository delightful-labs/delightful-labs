export { image_editor_contrast as "image_editor.contrast" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_ContrastInputs = {};
/**
* | output |
* | --- |
* | "Contrast" |
*
* @param {Image_Editor_ContrastInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_contrast: ((inputs?: Image_Editor_ContrastInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_ContrastInputs, {
    locale?: "en";
}, {}>;
