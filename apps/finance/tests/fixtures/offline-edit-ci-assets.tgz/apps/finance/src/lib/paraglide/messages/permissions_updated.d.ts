export { permissions_updated as "permissions.updated" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Permissions_UpdatedInputs = {};
/**
* | output |
* | --- |
* | "Permissions were updated." |
*
* @param {Permissions_UpdatedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const permissions_updated: ((inputs?: Permissions_UpdatedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Permissions_UpdatedInputs, {
    locale?: "en";
}, {}>;
