export { defaults_workspace as "defaults.workspace" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_WorkspaceInputs = {};
/**
* | output |
* | --- |
* | "Personal workspace" |
*
* @param {Defaults_WorkspaceInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_workspace: ((inputs?: Defaults_WorkspaceInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_WorkspaceInputs, {
    locale?: "en";
}, {}>;
