export { pwa_update_later as "pwa_update.later" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Pwa_Update_LaterInputs = {};
/**
* | output |
* | --- |
* | "Later" |
*
* @param {Pwa_Update_LaterInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const pwa_update_later: ((inputs?: Pwa_Update_LaterInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Pwa_Update_LaterInputs, {
    locale?: "en";
}, {}>;
