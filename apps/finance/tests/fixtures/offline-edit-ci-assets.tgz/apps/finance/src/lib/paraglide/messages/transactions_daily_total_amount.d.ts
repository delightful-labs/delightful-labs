export { transactions_daily_total_amount as "transactions.daily_total_amount" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Daily_Total_AmountInputs = {
    amount: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Daily total: {amount}" |
*
* @param {Transactions_Daily_Total_AmountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_daily_total_amount: ((inputs: Transactions_Daily_Total_AmountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Daily_Total_AmountInputs, {
    locale?: "en";
}, {}>;
