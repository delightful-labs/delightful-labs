export { actions_existing as "actions.existing" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_ExistingInputs = {};
/**
* | output |
* | --- |
* | "Already present" |
*
* @param {Actions_ExistingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_existing: ((inputs?: Actions_ExistingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_ExistingInputs, {
    locale?: "en";
}, {}>;
