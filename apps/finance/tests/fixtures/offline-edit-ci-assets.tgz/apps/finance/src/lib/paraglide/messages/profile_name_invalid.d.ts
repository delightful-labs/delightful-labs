export { profile_name_invalid as "profile.name_invalid" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Profile_Name_InvalidInputs = {};
/**
* | output |
* | --- |
* | "Enter a valid display name." |
*
* @param {Profile_Name_InvalidInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const profile_name_invalid: ((inputs?: Profile_Name_InvalidInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Profile_Name_InvalidInputs, {
    locale?: "en";
}, {}>;
