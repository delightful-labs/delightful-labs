export { forms_settling as "forms.settling" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_SettlingInputs = {};
/**
* | output |
* | --- |
* | "Finishing your change…" |
*
* @param {Forms_SettlingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_settling: ((inputs?: Forms_SettlingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_SettlingInputs, {
    locale?: "en";
}, {}>;
