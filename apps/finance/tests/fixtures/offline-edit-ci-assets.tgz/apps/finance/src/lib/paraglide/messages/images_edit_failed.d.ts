export { images_edit_failed as "images.edit_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Images_Edit_FailedInputs = {};
/**
* | output |
* | --- |
* | "The image could not be edited. Check it before trying again." |
*
* @param {Images_Edit_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const images_edit_failed: ((inputs?: Images_Edit_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Images_Edit_FailedInputs, {
    locale?: "en";
}, {}>;
