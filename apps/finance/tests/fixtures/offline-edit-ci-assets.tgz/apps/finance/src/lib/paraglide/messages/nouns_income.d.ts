export { nouns_income as "nouns.income" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_IncomeInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Income" |
* | * | "Income" |
*
* @param {Nouns_IncomeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_income: ((inputs: Nouns_IncomeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_IncomeInputs, {
    locale?: "en";
}, {}>;
