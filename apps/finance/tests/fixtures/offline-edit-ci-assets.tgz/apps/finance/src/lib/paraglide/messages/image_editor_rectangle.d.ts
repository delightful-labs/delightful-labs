export { image_editor_rectangle as "image_editor.rectangle" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_RectangleInputs = {};
/**
* | output |
* | --- |
* | "Freeform rectangle" |
*
* @param {Image_Editor_RectangleInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_rectangle: ((inputs?: Image_Editor_RectangleInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_RectangleInputs, {
    locale?: "en";
}, {}>;
