export { image_editor_loading as "image_editor.loading" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_LoadingInputs = {};
/**
* | output |
* | --- |
* | "Loading image…" |
*
* @param {Image_Editor_LoadingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_loading: ((inputs?: Image_Editor_LoadingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_LoadingInputs, {
    locale?: "en";
}, {}>;
