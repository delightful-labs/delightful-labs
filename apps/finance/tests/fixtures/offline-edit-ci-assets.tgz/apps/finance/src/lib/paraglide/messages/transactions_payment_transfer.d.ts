export { transactions_payment_transfer as "transactions.payment.transfer" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Payment_TransferInputs = {};
/**
* | output |
* | --- |
* | "Transfer" |
*
* @param {Transactions_Payment_TransferInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_payment_transfer: ((inputs?: Transactions_Payment_TransferInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Payment_TransferInputs, {
    locale?: "en";
}, {}>;
