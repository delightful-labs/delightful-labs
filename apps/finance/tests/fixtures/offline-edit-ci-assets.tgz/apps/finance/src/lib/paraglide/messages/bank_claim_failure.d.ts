export { bank_claim_failure as "bank.claim_failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Claim_FailureInputs = {};
/**
* | output |
* | --- |
* | "The setup token could not be claimed. It may already have been used or compromised; revoke it at SimpleFIN and obtain a new token." |
*
* @param {Bank_Claim_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_claim_failure: ((inputs?: Bank_Claim_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Claim_FailureInputs, {
    locale?: "en";
}, {}>;
