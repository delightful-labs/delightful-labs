export { labels_display_name as "labels.display_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Display_NameInputs = {};
/**
* | output |
* | --- |
* | "Display name" |
*
* @param {Labels_Display_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_display_name: ((inputs?: Labels_Display_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Display_NameInputs, {
    locale?: "en";
}, {}>;
