export { defaults_categories_transport as "defaults.categories.transport" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_TransportInputs = {};
/**
* | output |
* | --- |
* | "Transport" |
*
* @param {Defaults_Categories_TransportInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_transport: ((inputs?: Defaults_Categories_TransportInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_TransportInputs, {
    locale?: "en";
}, {}>;
