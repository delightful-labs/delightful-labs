export { labels_without_password as "labels.without_password" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Labels_Without_PasswordInputs = {};
/**
* | output |
* | --- |
* | "Without a password" |
*
* @param {Labels_Without_PasswordInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const labels_without_password: ((inputs?: Labels_Without_PasswordInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Labels_Without_PasswordInputs, {
    locale?: "en";
}, {}>;
