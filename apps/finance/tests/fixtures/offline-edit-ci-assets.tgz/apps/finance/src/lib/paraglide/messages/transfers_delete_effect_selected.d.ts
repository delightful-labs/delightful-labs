export { transfers_delete_effect_selected as "transfers.delete_effect_selected" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Delete_Effect_SelectedInputs = {};
/**
* | output |
* | --- |
* | "This transaction will be unlinked and deleted. The other transaction will remain as ordinary income or expense and count toward totals." |
*
* @param {Transfers_Delete_Effect_SelectedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_delete_effect_selected: ((inputs?: Transfers_Delete_Effect_SelectedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Delete_Effect_SelectedInputs, {
    locale?: "en";
}, {}>;
