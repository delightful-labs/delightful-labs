export { defaults_categories_housing as "defaults.categories.housing" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Defaults_Categories_HousingInputs = {};
/**
* | output |
* | --- |
* | "Housing" |
*
* @param {Defaults_Categories_HousingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const defaults_categories_housing: ((inputs?: Defaults_Categories_HousingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Defaults_Categories_HousingInputs, {
    locale?: "en";
}, {}>;
