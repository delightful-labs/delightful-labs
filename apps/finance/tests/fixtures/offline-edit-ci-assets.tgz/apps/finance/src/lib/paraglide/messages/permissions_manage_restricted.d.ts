export { permissions_manage_restricted as "permissions.manage_restricted" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Permissions_Manage_RestrictedInputs = {};
/**
* | output |
* | --- |
* | "Only workspace owners and admins can manage this permission." |
*
* @param {Permissions_Manage_RestrictedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const permissions_manage_restricted: ((inputs?: Permissions_Manage_RestrictedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Permissions_Manage_RestrictedInputs, {
    locale?: "en";
}, {}>;
