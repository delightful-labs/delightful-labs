export { transactions_no_accounts as "transactions.no_accounts" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_No_AccountsInputs = {};
/**
* | output |
* | --- |
* | "Add an account before recording a transaction." |
*
* @param {Transactions_No_AccountsInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_no_accounts: ((inputs?: Transactions_No_AccountsInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_No_AccountsInputs, {
    locale?: "en";
}, {}>;
