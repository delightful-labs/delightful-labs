export { actions_move_up_name as "actions.move_up_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Move_Up_NameInputs = {
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Move {name} up" |
*
* @param {Actions_Move_Up_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_move_up_name: ((inputs: Actions_Move_Up_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Move_Up_NameInputs, {
    locale?: "en";
}, {}>;
