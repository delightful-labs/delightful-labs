export { errors_not_found_description as "errors.not_found_description" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Not_Found_DescriptionInputs = {};
/**
* | output |
* | --- |
* | "The page you’re looking for could not be found." |
*
* @param {Errors_Not_Found_DescriptionInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_not_found_description: ((inputs?: Errors_Not_Found_DescriptionInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Not_Found_DescriptionInputs, {
    locale?: "en";
}, {}>;
