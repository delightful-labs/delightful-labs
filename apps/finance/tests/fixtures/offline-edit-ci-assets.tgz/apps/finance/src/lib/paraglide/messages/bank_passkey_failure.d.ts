export { bank_passkey_failure as "bank.passkey_failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Passkey_FailureInputs = {};
/**
* | output |
* | --- |
* | "Passkey encryption could not be verified. Your setup token has not been claimed. Use a compatible browser and password manager." |
*
* @param {Bank_Passkey_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_passkey_failure: ((inputs?: Bank_Passkey_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Passkey_FailureInputs, {
    locale?: "en";
}, {}>;
