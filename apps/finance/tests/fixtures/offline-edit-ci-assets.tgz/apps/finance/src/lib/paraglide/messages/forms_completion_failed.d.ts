export { forms_completion_failed as "forms.completion_failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Completion_FailedInputs = {};
/**
* | output |
* | --- |
* | "Your changes were saved, but the next page could not open. Retry to open it without saving again." |
*
* @param {Forms_Completion_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_completion_failed: ((inputs?: Forms_Completion_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Completion_FailedInputs, {
    locale?: "en";
}, {}>;
