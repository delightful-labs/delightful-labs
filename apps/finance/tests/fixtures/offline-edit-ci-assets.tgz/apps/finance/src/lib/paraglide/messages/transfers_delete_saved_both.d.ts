export { transfers_delete_saved_both as "transfers.delete_saved_both" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transfers_Delete_Saved_BothInputs = {};
/**
* | output |
* | --- |
* | "Both linked transactions were deleted on this device." |
*
* @param {Transfers_Delete_Saved_BothInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transfers_delete_saved_both: ((inputs?: Transfers_Delete_Saved_BothInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transfers_Delete_Saved_BothInputs, {
    locale?: "en";
}, {}>;
