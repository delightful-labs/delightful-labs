export { bank_setup_save_body as "bank.setup_save_body" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Setup_Save_BodyInputs = {};
/**
* | output |
* | --- |
* | "Both tests passed. Continue to claim your one-use SimpleFIN token, encrypt the credential and save the connection. This step does not fetch accounts or trans..." |
*
* @param {Bank_Setup_Save_BodyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_setup_save_body: ((inputs?: Bank_Setup_Save_BodyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Setup_Save_BodyInputs, {
    locale?: "en";
}, {}>;
