export { transactions_no_accounts_selected as "transactions.no_accounts_selected" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_No_Accounts_SelectedInputs = {};
/**
* | output |
* | --- |
* | "Turn on an account to see its transactions." |
*
* @param {Transactions_No_Accounts_SelectedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_no_accounts_selected: ((inputs?: Transactions_No_Accounts_SelectedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_No_Accounts_SelectedInputs, {
    locale?: "en";
}, {}>;
