export { bank_token as "bank.token" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_TokenInputs = {};
/**
* | output |
* | --- |
* | "SimpleFIN Bridge setup token" |
*
* @param {Bank_TokenInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_token: ((inputs?: Bank_TokenInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_TokenInputs, {
    locale?: "en";
}, {}>;
