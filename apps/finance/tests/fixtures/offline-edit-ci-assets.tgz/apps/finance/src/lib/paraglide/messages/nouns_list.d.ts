export { nouns_list as "nouns.list" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_ListInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "List" |
* | * | "Lists" |
*
* @param {Nouns_ListInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_list: ((inputs: Nouns_ListInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_ListInputs, {
    locale?: "en";
}, {}>;
