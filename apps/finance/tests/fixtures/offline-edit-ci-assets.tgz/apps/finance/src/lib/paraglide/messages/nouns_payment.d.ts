export { nouns_payment as "nouns.payment" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_PaymentInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Payment" |
* | * | "Payments" |
*
* @param {Nouns_PaymentInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_payment: ((inputs: Nouns_PaymentInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_PaymentInputs, {
    locale?: "en";
}, {}>;
