export { image_editor_failed as "image_editor.failed" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_FailedInputs = {};
/**
* | output |
* | --- |
* | "This image could not be edited. Cancel and try again." |
*
* @param {Image_Editor_FailedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_failed: ((inputs?: Image_Editor_FailedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_FailedInputs, {
    locale?: "en";
}, {}>;
