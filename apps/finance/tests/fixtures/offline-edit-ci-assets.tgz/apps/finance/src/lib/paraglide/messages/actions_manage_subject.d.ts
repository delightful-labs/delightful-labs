export { actions_manage_subject as "actions.manage_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Manage_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Manage {subject}" |
*
* @param {Actions_Manage_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_manage_subject: ((inputs: Actions_Manage_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Manage_SubjectInputs, {
    locale?: "en";
}, {}>;
