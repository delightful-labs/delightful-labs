export { bank_cancelled as "bank.cancelled" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_CancelledInputs = {};
/**
* | output |
* | --- |
* | "Operation cancelled. Credential locked. If token claim had begun, revoke it at SimpleFIN before reconnecting." |
*
* @param {Bank_CancelledInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_cancelled: ((inputs?: Bank_CancelledInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_CancelledInputs, {
    locale?: "en";
}, {}>;
