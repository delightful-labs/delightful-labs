export { nouns_profile as "nouns.profile" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_ProfileInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Profile" |
* | * | "Profiles" |
*
* @param {Nouns_ProfileInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_profile: ((inputs: Nouns_ProfileInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_ProfileInputs, {
    locale?: "en";
}, {}>;
