export { transactions_updated_at as "transactions.updated_at" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Updated_AtInputs = {};
/**
* | output |
* | --- |
* | "Last edited at" |
*
* @param {Transactions_Updated_AtInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_updated_at: ((inputs?: Transactions_Updated_AtInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Updated_AtInputs, {
    locale?: "en";
}, {}>;
