export { pwa_update_activated as "pwa_update.activated" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Pwa_Update_ActivatedInputs = {};
/**
* | output |
* | --- |
* | "A new version is active. Reload to use it." |
*
* @param {Pwa_Update_ActivatedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const pwa_update_activated: ((inputs?: Pwa_Update_ActivatedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Pwa_Update_ActivatedInputs, {
    locale?: "en";
}, {}>;
