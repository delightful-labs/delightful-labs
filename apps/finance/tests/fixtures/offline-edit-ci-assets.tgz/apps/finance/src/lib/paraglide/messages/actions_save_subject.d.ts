export { actions_save_subject as "actions.save_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Save_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Save {subject}" |
*
* @param {Actions_Save_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_save_subject: ((inputs: Actions_Save_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Save_SubjectInputs, {
    locale?: "en";
}, {}>;
