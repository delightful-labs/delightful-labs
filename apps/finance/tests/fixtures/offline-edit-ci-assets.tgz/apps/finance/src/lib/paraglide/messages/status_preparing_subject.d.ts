export { status_preparing_subject as "status.preparing_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Preparing_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Preparing {subject}…" |
*
* @param {Status_Preparing_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_preparing_subject: ((inputs: Status_Preparing_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Preparing_SubjectInputs, {
    locale?: "en";
}, {}>;
