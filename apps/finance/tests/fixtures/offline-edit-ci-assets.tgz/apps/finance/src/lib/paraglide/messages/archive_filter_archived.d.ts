export { archive_filter_archived as "archive_filter.archived" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Archive_Filter_ArchivedInputs = {};
/**
* | output |
* | --- |
* | "Archived only" |
*
* @param {Archive_Filter_ArchivedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const archive_filter_archived: ((inputs?: Archive_Filter_ArchivedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Archive_Filter_ArchivedInputs, {
    locale?: "en";
}, {}>;
