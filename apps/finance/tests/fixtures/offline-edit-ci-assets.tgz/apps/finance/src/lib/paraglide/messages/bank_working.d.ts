export { bank_working as "bank.working" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_WorkingInputs = {};
/**
* | output |
* | --- |
* | "Waiting for passkey verification or completing your requested operation…" |
*
* @param {Bank_WorkingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_working: ((inputs?: Bank_WorkingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_WorkingInputs, {
    locale?: "en";
}, {}>;
