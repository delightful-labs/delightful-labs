export { developer_jazz_server_url as "developer.jazz_server_url" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_Jazz_Server_UrlInputs = {};
/**
* | output |
* | --- |
* | "Jazz server URL" |
*
* @param {Developer_Jazz_Server_UrlInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_jazz_server_url: ((inputs?: Developer_Jazz_Server_UrlInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_Jazz_Server_UrlInputs, {
    locale?: "en";
}, {}>;
