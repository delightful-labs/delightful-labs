export { actions_create_another_subject as "actions.create_another_subject" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Actions_Create_Another_SubjectInputs = {
    subject: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Create another {subject}" |
*
* @param {Actions_Create_Another_SubjectInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const actions_create_another_subject: ((inputs: Actions_Create_Another_SubjectInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Actions_Create_Another_SubjectInputs, {
    locale?: "en";
}, {}>;
