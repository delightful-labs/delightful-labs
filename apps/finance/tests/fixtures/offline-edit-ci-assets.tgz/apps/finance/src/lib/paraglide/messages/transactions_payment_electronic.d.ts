export { transactions_payment_electronic as "transactions.payment.electronic" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Payment_ElectronicInputs = {};
/**
* | output |
* | --- |
* | "Electronic" |
*
* @param {Transactions_Payment_ElectronicInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_payment_electronic: ((inputs?: Transactions_Payment_ElectronicInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Payment_ElectronicInputs, {
    locale?: "en";
}, {}>;
