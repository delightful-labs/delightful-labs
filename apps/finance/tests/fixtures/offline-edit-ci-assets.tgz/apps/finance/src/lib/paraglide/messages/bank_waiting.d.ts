export { bank_waiting as "bank.waiting" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_WaitingInputs = {};
/**
* | output |
* | --- |
* | "Waiting for encrypted credentials to replicate, or reconnection is required." |
*
* @param {Bank_WaitingInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_waiting: ((inputs?: Bank_WaitingInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_WaitingInputs, {
    locale?: "en";
}, {}>;
