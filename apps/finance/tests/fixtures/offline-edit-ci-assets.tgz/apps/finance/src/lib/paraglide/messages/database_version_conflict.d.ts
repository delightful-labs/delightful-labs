export { database_version_conflict as "database.version_conflict" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Database_Version_ConflictInputs = {};
/**
* | output |
* | --- |
* | "Finance is open in another version. Update your other Finance windows to continue. This window will resume automatically." |
*
* @param {Database_Version_ConflictInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const database_version_conflict: ((inputs?: Database_Version_ConflictInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Database_Version_ConflictInputs, {
    locale?: "en";
}, {}>;
