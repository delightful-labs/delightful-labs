export { transactions_samples_failed_count as "transactions.samples.failed_count" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Transactions_Samples_Failed_CountInputs = {
    count: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "Stopped after saving {count} of 25. Select a writable active account and make sure a category is available before trying again." |
*
* @param {Transactions_Samples_Failed_CountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const transactions_samples_failed_count: ((inputs: Transactions_Samples_Failed_CountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Transactions_Samples_Failed_CountInputs, {
    locale?: "en";
}, {}>;
