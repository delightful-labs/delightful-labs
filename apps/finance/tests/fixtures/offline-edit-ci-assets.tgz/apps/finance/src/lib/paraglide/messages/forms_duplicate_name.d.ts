export { forms_duplicate_name as "forms.duplicate_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Forms_Duplicate_NameInputs = {};
/**
* | output |
* | --- |
* | "An active item with this name already exists. Choose another name." |
*
* @param {Forms_Duplicate_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const forms_duplicate_name: ((inputs?: Forms_Duplicate_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Forms_Duplicate_NameInputs, {
    locale?: "en";
}, {}>;
