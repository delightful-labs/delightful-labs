export { errors_permission_denied as "errors.permission_denied" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Errors_Permission_DeniedInputs = {};
/**
* | output |
* | --- |
* | "You don’t have permission to do this." |
*
* @param {Errors_Permission_DeniedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const errors_permission_denied: ((inputs?: Errors_Permission_DeniedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Errors_Permission_DeniedInputs, {
    locale?: "en";
}, {}>;
