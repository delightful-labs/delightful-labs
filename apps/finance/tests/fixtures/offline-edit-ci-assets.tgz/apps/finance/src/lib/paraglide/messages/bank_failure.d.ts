export { bank_failure as "bank.failure" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_FailureInputs = {};
/**
* | output |
* | --- |
* | "The operation failed or passkey verification was cancelled. No automatic retry will occur. Verify your passkey, connectivity and account mappings." |
*
* @param {Bank_FailureInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_failure: ((inputs?: Bank_FailureInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_FailureInputs, {
    locale?: "en";
}, {}>;
