export { status_selected_subject_name as "status.selected_subject_name" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Selected_Subject_NameInputs = {
    subject: NonNullable<unknown>;
    name: NonNullable<unknown>;
};
/**
* | output |
* | --- |
* | "{subject} {name} selected." |
*
* @param {Status_Selected_Subject_NameInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_selected_subject_name: ((inputs: Status_Selected_Subject_NameInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Selected_Subject_NameInputs, {
    locale?: "en";
}, {}>;
