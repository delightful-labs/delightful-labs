export { developer_browser_origin as "developer.browser_origin" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Developer_Browser_OriginInputs = {};
/**
* | output |
* | --- |
* | "Browser origin" |
*
* @param {Developer_Browser_OriginInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const developer_browser_origin: ((inputs?: Developer_Browser_OriginInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Developer_Browser_OriginInputs, {
    locale?: "en";
}, {}>;
