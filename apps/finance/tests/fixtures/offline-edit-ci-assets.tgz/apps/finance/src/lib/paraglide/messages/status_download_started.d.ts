export { status_download_started as "status.download_started" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Status_Download_StartedInputs = {};
/**
* | output |
* | --- |
* | "Download started." |
*
* @param {Status_Download_StartedInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const status_download_started: ((inputs?: Status_Download_StartedInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Status_Download_StartedInputs, {
    locale?: "en";
}, {}>;
