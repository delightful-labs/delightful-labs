export { pwa_update_busy as "pwa_update.busy" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Pwa_Update_BusyInputs = {};
/**
* | output |
* | --- |
* | "Updating and reloading…" |
*
* @param {Pwa_Update_BusyInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const pwa_update_busy: ((inputs?: Pwa_Update_BusyInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Pwa_Update_BusyInputs, {
    locale?: "en";
}, {}>;
