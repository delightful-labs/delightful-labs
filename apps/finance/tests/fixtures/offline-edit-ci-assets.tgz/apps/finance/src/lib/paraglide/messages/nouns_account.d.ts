export { nouns_account as "nouns.account" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Nouns_AccountInputs = {
    count: NonNullable<unknown>;
};
/**
* | countPlural | output |
* | --- | --- |
* | "one" | "Account" |
* | * | "Accounts" |
*
* @param {Nouns_AccountInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const nouns_account: ((inputs: Nouns_AccountInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Nouns_AccountInputs, {
    locale?: "en";
}, {}>;
