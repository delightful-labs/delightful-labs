export { image_editor_crop_mode as "image_editor.crop_mode" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Image_Editor_Crop_ModeInputs = {};
/**
* | output |
* | --- |
* | "Crop shape" |
*
* @param {Image_Editor_Crop_ModeInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const image_editor_crop_mode: ((inputs?: Image_Editor_Crop_ModeInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Image_Editor_Crop_ModeInputs, {
    locale?: "en";
}, {}>;
