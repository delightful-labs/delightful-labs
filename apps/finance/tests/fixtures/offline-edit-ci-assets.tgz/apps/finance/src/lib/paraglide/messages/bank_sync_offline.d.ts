export { bank_sync_offline as "bank.sync_offline" };
export type LocalizedString = import("../runtime.js").LocalizedString;
export type Bank_Sync_OfflineInputs = {};
/**
* | output |
* | --- |
* | "Sync is not available offline. Connect to the internet to sync your bank transactions." |
*
* @param {Bank_Sync_OfflineInputs} inputs
* @param {{ locale?: "en" }} options
* @returns {LocalizedString}
*/
declare const bank_sync_offline: ((inputs?: Bank_Sync_OfflineInputs, options?: {
    locale?: "en";
}) => LocalizedString) & import("../runtime.js").MessageMetadata<Bank_Sync_OfflineInputs, {
    locale?: "en";
}, {}>;
